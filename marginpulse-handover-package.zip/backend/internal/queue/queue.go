// Package queue ports app/services/queue_service.py — publishes JSON
// task messages to SQS, consumed by the Lambda worker (cmd/worker).
package queue

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"sync"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/sqs"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/config"
)

var (
	clientOnce sync.Once
	client     *sqs.Client
)

func getClient() *sqs.Client {
	clientOnce.Do(func() {
		cfg := config.Get()
		ctx := context.Background()
		optFns := []func(*awsconfig.LoadOptions) error{awsconfig.WithRegion(cfg.AWSRegion)}
		if cfg.AWSAccessKeyID != "" {
			optFns = append(optFns, awsconfig.WithCredentialsProvider(
				credentials.NewStaticCredentialsProvider(cfg.AWSAccessKeyID, cfg.AWSSecretKey, ""),
			))
		}
		awsCfg, err := awsconfig.LoadDefaultConfig(ctx, optFns...)
		if err != nil {
			panic(fmt.Sprintf("failed to load AWS config for SQS: %v", err))
		}
		client = sqs.NewFromConfig(awsCfg)
	})
	return client
}

type message struct {
	Task  string                 `json:"task"`
	JobID string                 `json:"job_id"`
	Args  map[string]interface{} `json:"args"`
}

func send(ctx context.Context, queueURL, taskName string, args map[string]interface{}) (string, error) {
	if queueURL == "" {
		return "", fmt.Errorf("no SQS queue URL configured for task %q", taskName)
	}
	jobID := uuid.NewString()
	body, err := json.Marshal(message{Task: taskName, JobID: jobID, Args: args})
	if err != nil {
		return "", err
	}
	_, err = getClient().SendMessage(ctx, &sqs.SendMessageInput{
		QueueUrl:    aws.String(queueURL),
		MessageBody: aws.String(string(body)),
	})
	if err != nil {
		slog.Error("sqs_dispatch_failed", "task", taskName, "error", err)
		return "", fmt.Errorf("failed to enqueue task %q: %w", taskName, err)
	}
	slog.Info("sqs_dispatch_ok", "task", taskName, "job_id", jobID)
	return jobID, nil
}

func EnqueueOCRPipeline(ctx context.Context, documentID, s3Key, mimeType, tenantID string) (string, error) {
	cfg := config.Get()
	return send(ctx, cfg.SQSQueueURLOCR, "run_ocr_pipeline", map[string]interface{}{
		"document_id": documentID, "s3_key": s3Key, "mime_type": mimeType, "tenant_id": tenantID,
	})
}

func EnqueueReconciliation(ctx context.Context, documentID, tenantID string) (string, error) {
	cfg := config.Get()
	return send(ctx, cfg.SQSQueueURLReconcile, "run_reconciliation", map[string]interface{}{
		"document_id": documentID, "tenant_id": tenantID,
	})
}

func EnqueueGSTSync(ctx context.Context, tenantID, gstin, period string) (string, error) {
	cfg := config.Get()
	return send(ctx, cfg.SQSQueueURLGST, "sync_gst_portal", map[string]interface{}{
		"tenant_id": tenantID, "gstin": gstin, "period": period,
	})
}

func EnqueueTaxIdentifierVerification(ctx context.Context, taxIdentifierID, tenantID string) (string, error) {
	cfg := config.Get()
	return send(ctx, cfg.SQSQueueURLTaxID, "verify_tax_identifier", map[string]interface{}{
		"tax_identifier_id": taxIdentifierID, "tenant_id": tenantID,
	})
}

func EnqueueBankAccountVerification(ctx context.Context, bankAccountID, tenantID string) (string, error) {
	cfg := config.Get()
	return send(ctx, cfg.SQSQueueURLBankAcct, "verify_bank_account_task", map[string]interface{}{
		"bank_account_id": bankAccountID, "tenant_id": tenantID,
	})
}
