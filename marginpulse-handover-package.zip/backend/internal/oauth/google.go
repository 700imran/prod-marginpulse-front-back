package oauth

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/marginpulse/backend/internal/platformsettings"
)

// GoogleUserInfo is what we actually need from Google's userinfo
// endpoint after exchanging the authorization code.
type GoogleUserInfo struct {
	Sub           string `json:"sub"`
	Email         string `json:"email"`
	EmailVerified bool   `json:"email_verified"`
	Name          string `json:"name"`
	Picture       string `json:"picture"`
}

// GoogleTokens is the raw token response — AccessToken/RefreshToken are
// only useful if you also want to call other Google APIs later (e.g.
// Google Meet/Calendar) on the tenant's behalf; for pure "Sign in with
// Google" only the ID token / userinfo matters.
type GoogleTokens struct {
	AccessToken  string
	RefreshToken string
	ExpiresIn    int
}

var httpClient = &http.Client{Timeout: 15 * time.Second}

// GoogleAuthURL builds the redirect URL to Google's OAuth consent
// screen. Client ID/redirect URI are resolved via platformsettings —
// admin-panel overrides win over the deploy-time env var defaults, so
// an admin can change these without a redeploy. scope defaults to the
// minimum needed for login (openid, email, profile).
func GoogleAuthURL(ctx context.Context, state string, extraScopes ...string) (string, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return "", err
	}
	scopes := "openid email profile"
	for _, s := range extraScopes {
		scopes += " " + s
	}
	v := url.Values{}
	v.Set("client_id", settings.GoogleClientID)
	v.Set("redirect_uri", settings.GoogleRedirectURI)
	v.Set("response_type", "code")
	v.Set("scope", scopes)
	v.Set("state", state)
	v.Set("access_type", "offline") // request a refresh_token
	v.Set("prompt", "consent select_account")
	return "https://accounts.google.com/o/oauth2/v2/auth?" + v.Encode(), nil
}

// GoogleExchangeCode exchanges the authorization code for tokens, then
// fetches the user's profile — mirrors the standard OAuth2 authorization
// code flow, hand-rolled via net/http since there's no dependency-light
// reason to pull in golang.org/x/oauth2 for two HTTP calls.
func GoogleExchangeCode(ctx context.Context, code string) (*GoogleUserInfo, *GoogleTokens, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return nil, nil, err
	}

	form := url.Values{}
	form.Set("client_id", settings.GoogleClientID)
	form.Set("client_secret", settings.GoogleClientSecret)
	form.Set("code", code)
	form.Set("redirect_uri", settings.GoogleRedirectURI)
	form.Set("grant_type", "authorization_code")

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://oauth2.googleapis.com/token", strings.NewReader(form.Encode()))
	if err != nil {
		return nil, nil, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()

	var tokenResp struct {
		AccessToken  string `json:"access_token"`
		RefreshToken string `json:"refresh_token"`
		ExpiresIn    int    `json:"expires_in"`
		Error        string `json:"error"`
		ErrorDesc    string `json:"error_description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		return nil, nil, err
	}
	if resp.StatusCode >= 400 || tokenResp.Error != "" {
		return nil, nil, fmt.Errorf("google token exchange failed: %s: %s", tokenResp.Error, tokenResp.ErrorDesc)
	}

	userReq, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://www.googleapis.com/oauth2/v3/userinfo", nil)
	if err != nil {
		return nil, nil, err
	}
	userReq.Header.Set("Authorization", "Bearer "+tokenResp.AccessToken)
	userResp, err := httpClient.Do(userReq)
	if err != nil {
		return nil, nil, err
	}
	defer userResp.Body.Close()

	var userInfo GoogleUserInfo
	if err := json.NewDecoder(userResp.Body).Decode(&userInfo); err != nil {
		return nil, nil, err
	}
	if userInfo.Email == "" {
		return nil, nil, fmt.Errorf("google did not return an email address — check the 'email' scope is granted")
	}

	return &userInfo, &GoogleTokens{
		AccessToken: tokenResp.AccessToken, RefreshToken: tokenResp.RefreshToken, ExpiresIn: tokenResp.ExpiresIn,
	}, nil
}
