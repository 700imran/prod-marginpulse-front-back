// Package oauth implements the OAuth2 / Sign-in-with-Apple login flows
// (Google, Apple) plus the shared CSRF-state mechanism both use.
package oauth

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"

	"github.com/marginpulse/backend/internal/config"
)

const stateTTL = 10 * time.Minute

var client *redis.Client

func getClient() *redis.Client {
	if client == nil {
		opts, err := redis.ParseURL(config.Get().RedisURL)
		if err != nil {
			opts = &redis.Options{Addr: "localhost:6379"}
		}
		client = redis.NewClient(opts)
	}
	return client
}

// NewState generates a random CSRF state token and stores what it's for
// (which OAuth flow, and — for the account-linking case — which tenant
// initiated it) in Redis with a short TTL. Google/Apple echo this state
// value back unmodified in the callback, so we can verify the callback
// actually followed a redirect we issued, not a forged request.
func NewState(ctx context.Context, purpose string) (string, error) {
	b := make([]byte, 24)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	state := hex.EncodeToString(b)
	key := "mp:oauth_state:" + state
	if err := getClient().Set(ctx, key, purpose, stateTTL).Err(); err != nil {
		return "", err
	}
	return state, nil
}

// ConsumeState validates and immediately deletes a state token (one-time
// use — prevents a captured callback URL from being replayed) and
// returns what it was issued for.
func ConsumeState(ctx context.Context, state string) (string, error) {
	key := "mp:oauth_state:" + state
	purpose, err := getClient().Get(ctx, key).Result()
	if err != nil {
		return "", fmt.Errorf("invalid or expired OAuth state")
	}
	getClient().Del(ctx, key)
	return purpose, nil
}
