package oauth

import (
	"context"
	"crypto/ecdsa"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"math/big"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/marginpulse/backend/internal/platformsettings"
)

// AppleUserInfo is what we extract from the verified id_token — Apple's
// callback (unlike Google's) doesn't have a separate userinfo endpoint;
// everything needed is already inside the id_token's claims.
type AppleUserInfo struct {
	Sub           string
	Email         string
	EmailVerified bool
}

// AppleAuthURL builds the redirect URL to Apple's Sign-in page.
// response_mode=form_post is required whenever the "email"/"name" scope
// is requested — Apple POSTs the result back rather than using a query
// string redirect, which is why the callback route must accept POST
// (see httpapi router: apple callback is POST, google's is GET).
func AppleAuthURL(ctx context.Context, state string) (string, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return "", err
	}
	v := url.Values{}
	v.Set("client_id", settings.AppleClientID)
	v.Set("redirect_uri", settings.AppleRedirectURI)
	v.Set("response_type", "code")
	v.Set("scope", "name email")
	v.Set("response_mode", "form_post")
	v.Set("state", state)
	return "https://appleid.apple.com/auth/authorize?" + v.Encode(), nil
}

// generateClientSecret builds the ES256-signed JWT Apple requires as the
// token endpoint's "client_secret" — Apple doesn't issue a static secret
// the way Google does; you mint a new short-lived one (max 6 months
// validity per Apple's rules, but generating a fresh 5-minute one per
// request is simplest and avoids any rotation/expiry bookkeeping).
func generateClientSecret(ctx context.Context) (string, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return "", err
	}

	block, _ := pem.Decode([]byte(settings.ApplePrivateKey))
	if block == nil {
		return "", fmt.Errorf("Apple private key is not valid PEM (APPLE_PRIVATE_KEY or admin-panel override)")
	}
	keyIfc, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return "", fmt.Errorf("could not parse Apple private key: %w", err)
	}
	privateKey, ok := keyIfc.(*ecdsa.PrivateKey)
	if !ok {
		return "", fmt.Errorf("Apple private key is not an ECDSA key (expected the .p8 file's contents)")
	}

	now := time.Now()
	claims := jwt.RegisteredClaims{
		Issuer:    settings.AppleTeamID,
		IssuedAt:  jwt.NewNumericDate(now),
		ExpiresAt: jwt.NewNumericDate(now.Add(5 * time.Minute)),
		Audience:  jwt.ClaimStrings{"https://appleid.apple.com"},
		Subject:   settings.AppleClientID,
	}
	token := jwt.NewWithClaims(jwt.SigningMethodES256, claims)
	token.Header["kid"] = settings.AppleKeyID
	return token.SignedString(privateKey)
}

type appleJWK struct {
	Kty string `json:"kty"`
	Kid string `json:"kid"`
	Use string `json:"use"`
	Alg string `json:"alg"`
	N   string `json:"n"`
	E   string `json:"e"`
}

// fetchApplePublicKey retrieves Apple's current signing keys and builds
// the *rsa.PublicKey matching the given kid — Apple rotates these keys,
// so this is fetched fresh per verification rather than cached
// long-term (an in-memory cache with the JWKS response's own cache
// headers would be a reasonable future optimization; correctness matters
// more than the extra HTTP round trip here).
func fetchApplePublicKey(ctx context.Context, kid string) (*rsa.PublicKey, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://appleid.apple.com/auth/keys", nil)
	if err != nil {
		return nil, err
	}
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var body struct {
		Keys []appleJWK `json:"keys"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return nil, err
	}

	for _, k := range body.Keys {
		if k.Kid != kid {
			continue
		}
		nBytes, err := base64.RawURLEncoding.DecodeString(k.N)
		if err != nil {
			return nil, err
		}
		eBytes, err := base64.RawURLEncoding.DecodeString(k.E)
		if err != nil {
			return nil, err
		}
		n := new(big.Int).SetBytes(nBytes)
		e := new(big.Int).SetBytes(eBytes)
		return &rsa.PublicKey{N: n, E: int(e.Int64())}, nil
	}
	return nil, fmt.Errorf("no Apple signing key found matching kid %q", kid)
}

// AppleExchangeCode exchanges the authorization code for an id_token,
// then verifies its signature against Apple's live JWKS before trusting
// any claim inside it — an unverified id_token would let anyone forge a
// login by crafting their own JWT with an arbitrary email claim.
func AppleExchangeCode(ctx context.Context, code string) (*AppleUserInfo, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return nil, err
	}

	clientSecret, err := generateClientSecret(ctx)
	if err != nil {
		return nil, err
	}

	form := url.Values{}
	form.Set("client_id", settings.AppleClientID)
	form.Set("client_secret", clientSecret)
	form.Set("code", code)
	form.Set("redirect_uri", settings.AppleRedirectURI)
	form.Set("grant_type", "authorization_code")

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://appleid.apple.com/auth/token", strings.NewReader(form.Encode()))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var tokenResp struct {
		IDToken string `json:"id_token"`
		Error   string `json:"error"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&tokenResp); err != nil {
		return nil, err
	}
	if resp.StatusCode >= 400 || tokenResp.Error != "" {
		return nil, fmt.Errorf("apple token exchange failed: %s", tokenResp.Error)
	}

	var claims jwt.MapClaims
	token, err := jwt.ParseWithClaims(tokenResp.IDToken, &claims, func(t *jwt.Token) (interface{}, error) {
		kid, _ := t.Header["kid"].(string)
		if kid == "" {
			return nil, fmt.Errorf("apple id_token missing kid header")
		}
		return fetchApplePublicKey(ctx, kid)
	})
	if err != nil || !token.Valid {
		return nil, fmt.Errorf("apple id_token verification failed: %w", err)
	}

	email, _ := claims["email"].(string)
	sub, _ := claims["sub"].(string)
	if email == "" || sub == "" {
		return nil, fmt.Errorf("apple id_token missing sub/email claims")
	}
	emailVerified := false
	if v, ok := claims["email_verified"]; ok {
		switch vv := v.(type) {
		case bool:
			emailVerified = vv
		case string:
			emailVerified = vv == "true"
		}
	}

	return &AppleUserInfo{Sub: sub, Email: email, EmailVerified: emailVerified}, nil
}
