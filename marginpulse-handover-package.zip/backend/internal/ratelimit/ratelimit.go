// Package ratelimit ports app/core/rate_limit.py (slowapi + Redis) using
// a fixed-window counter — the same algorithm slowapi's Redis storage
// backend uses under the hood for "N per minute/hour" style limits.
package ratelimit

import (
	"context"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"

	"github.com/marginpulse/backend/internal/config"
)

var client *redis.Client

func getClient() *redis.Client {
	if client == nil {
		opts, err := redis.ParseURL(config.Get().RedisURL)
		if err != nil {
			slog.Error("invalid REDIS_URL for rate limiter", "error", err)
			opts = &redis.Options{Addr: "localhost:6379"}
		}
		client = redis.NewClient(opts)
	}
	return client
}

// Limit describes a "N per window" rate limit, e.g. Limit{Count: 5, Window: time.Minute}
// — the Go equivalent of slowapi's "5/minute" string.
type Limit struct {
	Count  int64
	Window time.Duration
}

// Result carries what the middleware needs to set X-RateLimit-* headers,
// mirroring slowapi's headers_enabled=True behavior.
type Result struct {
	Allowed   bool
	Limit     int64
	Remaining int64
	ResetUnix int64
}

// ClientIP extracts the caller's IP the same way slowapi's
// get_remote_address does — checking X-Forwarded-For first (set by API
// Gateway/load balancers) before falling back to the raw connection
// address, since Lambda-behind-API-Gateway never sees the real client
// IP on r.RemoteAddr directly.
func ClientIP(r *http.Request) string {
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
		parts := strings.Split(xff, ",")
		return strings.TrimSpace(parts[0])
	}
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

// Check enforces `limit` for `key` (typically "route:ip"). Fails OPEN
// (allowed=true) on Redis errors — mirrors the Python version's
// swallow_errors=True + in_memory_fallback_enabled=True design: a brief
// Redis outage degrades to "no rate limiting for a moment", not "every
// request 500s". A true in-process fallback counter (matching
// in_memory_fallback_enabled exactly) is deliberately not implemented
// here — under Lambda, each concurrent execution environment has its own
// process memory anyway, so an in-memory counter would only ever see a
// fraction of total traffic and give a false sense of continued
// enforcement; failing open and logging is the more honest behavior for
// this specific deployment target.
func Check(ctx context.Context, key string, limit Limit) Result {
	window := int64(limit.Window.Seconds())
	bucket := time.Now().Unix() / window
	redisKey := fmt.Sprintf("mp:ratelimit:%s:%d", key, bucket)

	c := getClient()
	count, err := c.Incr(ctx, redisKey).Result()
	if err != nil {
		slog.Warn("rate limit check failed open (redis error)", "key", key, "error", err)
		return Result{Allowed: true, Limit: limit.Count, Remaining: limit.Count, ResetUnix: (bucket + 1) * window}
	}
	if count == 1 {
		c.Expire(ctx, redisKey, limit.Window)
	}

	remaining := limit.Count - count
	if remaining < 0 {
		remaining = 0
	}
	return Result{
		Allowed:   count <= limit.Count,
		Limit:     limit.Count,
		Remaining: remaining,
		ResetUnix: (bucket + 1) * window,
	}
}

// SetHeaders writes X-RateLimit-* response headers, matching slowapi's
// headers_enabled=True output format.
func SetHeaders(w http.ResponseWriter, r Result) {
	w.Header().Set("X-RateLimit-Limit", strconv.FormatInt(r.Limit, 10))
	w.Header().Set("X-RateLimit-Remaining", strconv.FormatInt(r.Remaining, 10))
	w.Header().Set("X-RateLimit-Reset", strconv.FormatInt(r.ResetUnix, 10))
}
