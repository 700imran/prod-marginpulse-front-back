// Package platformsettings merges the admin-panel-editable
// PlatformSettingsItem (DynamoDB) with the deploy-time env var defaults
// (internal/config) — DynamoDB values win when present, so a fresh
// deployment works purely from environment variables until an admin
// opens the panel and overrides something, and the "revert to deploy
// default" behavior is simply "clear the field in the admin panel."
package platformsettings

import (
	"context"

	"github.com/marginpulse/backend/internal/config"
	"github.com/marginpulse/backend/internal/repository"
	"github.com/marginpulse/backend/internal/security"
)

// Resolved is the effective, ready-to-use configuration after merging
// DynamoDB overrides over env var defaults — every call site (oauth
// package, integrations/slack.go) reads from this instead of
// config.Get() directly for the fields an admin can override.
type Resolved struct {
	GoogleClientID     string
	GoogleClientSecret string
	GoogleRedirectURI  string

	AppleClientID    string
	AppleTeamID      string
	AppleKeyID       string
	ApplePrivateKey  string
	AppleRedirectURI string

	SlackClientID     string
	SlackClientSecret string
	SlackRedirectURI  string

	AIInsightsEnabled     bool
	WhatsAppIngestEnabled bool
	EmailIngestEnabled    bool
	RazorpayEnabled       bool
	StripeEnabled         bool
	SlackIntegrationOn    bool
	NewSignupsEnabled     bool
}

func pick(override, fallback string) string {
	if override != "" {
		return override
	}
	return fallback
}

func pickBool(override *bool, fallback bool) bool {
	if override != nil {
		return *override
	}
	return fallback
}

// Get fetches PlatformSettingsItem from DynamoDB and merges it over
// env-configured defaults. Decrypts any admin-panel-entered secrets
// (they're stored encrypted at rest via the same AES-256-GCM used for
// bank account numbers).
func Get(ctx context.Context) (*Resolved, error) {
	cfg := config.Get()
	repo := repository.NewPlatformSettingsRepo()
	item, err := repo.Get(ctx)
	if err != nil {
		// Fail open to env-var-only config — an admin-settings read
		// failure shouldn't take down login/OAuth entirely when the
		// deploy-time defaults would have worked fine on their own.
		item = &repository.PlatformSettingsItem{}
	}

	googleSecret := cfg.GoogleClientSecret
	if item.GoogleClientSecretEnc != "" {
		if dec, decErr := security.DecryptField(item.GoogleClientSecretEnc); decErr == nil {
			googleSecret = dec
		}
	}
	applePrivateKey := cfg.ApplePrivateKey
	if item.ApplePrivateKeyEnc != "" {
		if dec, decErr := security.DecryptField(item.ApplePrivateKeyEnc); decErr == nil {
			applePrivateKey = dec
		}
	}
	slackSecret := cfg.SlackClientSecret
	if item.SlackClientSecretEnc != "" {
		if dec, decErr := security.DecryptField(item.SlackClientSecretEnc); decErr == nil {
			slackSecret = dec
		}
	}

	return &Resolved{
		GoogleClientID:     pick(item.GoogleClientID, cfg.GoogleClientID),
		GoogleClientSecret: googleSecret,
		GoogleRedirectURI:  pick(item.GoogleRedirectURI, cfg.GoogleRedirectURI),

		AppleClientID:    pick(item.AppleClientID, cfg.AppleClientID),
		AppleTeamID:      pick(item.AppleTeamID, cfg.AppleTeamID),
		AppleKeyID:       pick(item.AppleKeyID, cfg.AppleKeyID),
		ApplePrivateKey:  applePrivateKey,
		AppleRedirectURI: pick(item.AppleRedirectURI, cfg.AppleRedirectURI),

		SlackClientID:     pick(item.SlackClientID, cfg.SlackClientID),
		SlackClientSecret: slackSecret,
		SlackRedirectURI:  pick(item.SlackRedirectURI, cfg.SlackRedirectURI),

		AIInsightsEnabled:     pickBool(item.AIInsightsEnabled, true),
		WhatsAppIngestEnabled: pickBool(item.WhatsAppIngestEnabled, true),
		EmailIngestEnabled:    pickBool(item.EmailIngestEnabled, true),
		RazorpayEnabled:       pickBool(item.RazorpayIntegrationOn, true),
		StripeEnabled:         pickBool(item.StripeIntegrationOn, true),
		SlackIntegrationOn:    pickBool(item.SlackIntegrationOn, true),
		NewSignupsEnabled:     pickBool(item.NewSignupsEnabled, true),
	}, nil
}
