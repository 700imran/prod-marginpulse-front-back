// Package storage ports app/services/storage_service.py's dual-mode
// backend (local filesystem for dev, S3-compatible for production).
package storage

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"

	"github.com/marginpulse/backend/internal/config"
)

var (
	s3ClientOnce sync.Once
	s3Client     *s3.Client
	s3Presign    *s3.PresignClient
)

func getS3Client() (*s3.Client, *s3.PresignClient) {
	s3ClientOnce.Do(func() {
		cfg := config.Get()
		ctx := context.Background()
		optFns := []func(*awsconfig.LoadOptions) error{awsconfig.WithRegion(cfg.S3Region)}
		if cfg.AWSAccessKeyID != "" {
			optFns = append(optFns, awsconfig.WithCredentialsProvider(
				credentials.NewStaticCredentialsProvider(cfg.AWSAccessKeyID, cfg.AWSSecretKey, ""),
			))
		}
		awsCfg, err := awsconfig.LoadDefaultConfig(ctx, optFns...)
		if err != nil {
			panic(fmt.Sprintf("failed to load AWS config for S3: %v", err))
		}
		var s3OptFns []func(*s3.Options)
		if cfg.S3EndpointURL != "" {
			s3OptFns = append(s3OptFns, func(o *s3.Options) {
				o.BaseEndpoint = aws.String(cfg.S3EndpointURL)
				o.UsePathStyle = true // required by R2 and most non-AWS S3-compatible providers
			})
		}
		s3Client = s3.NewFromConfig(awsCfg, s3OptFns...)
		s3Presign = s3.NewPresignClient(s3Client)
	})
	return s3Client, s3Presign
}

// resolveSafePath mirrors _resolve_safe_path() — guarantees a storage
// key can never escape LOCAL_STORAGE_PATH via "../" segments.
func resolveSafePath(key string) (string, error) {
	root, err := filepath.Abs(config.Get().LocalStoragePath)
	if err != nil {
		return "", err
	}
	candidate := filepath.Join(root, key)
	candidateAbs, err := filepath.Abs(candidate)
	if err != nil {
		return "", err
	}
	rel, err := filepath.Rel(root, candidateAbs)
	if err != nil || strings.HasPrefix(rel, "..") {
		return "", fmt.Errorf("storage key resolves outside the storage root: %q", key)
	}
	return candidateAbs, nil
}

func localUpload(data []byte, key string) (string, error) {
	dest, err := resolveSafePath(key)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
		return "", err
	}
	if err := os.WriteFile(dest, data, 0o644); err != nil {
		return "", err
	}
	slog.Info("saved locally", "path", dest, "size", len(data))
	return key, nil
}

func localDownload(key string) ([]byte, error) {
	path, err := resolveSafePath(key)
	if err != nil {
		return nil, err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return nil, fmt.Errorf("local file not found: %s", key)
		}
		return nil, err
	}
	return data, nil
}

func localPresignedURL(key string) (string, error) {
	if _, err := resolveSafePath(key); err != nil {
		return "", err
	}
	return "http://localhost:8000/api/v1/documents/file/" + url.PathEscape(key), nil
}

func s3Upload(ctx context.Context, data []byte, key, contentType string) (string, error) {
	cfg := config.Get()
	client, _ := getS3Client()
	input := &s3.PutObjectInput{
		Bucket:      aws.String(cfg.S3BucketName),
		Key:         aws.String(key),
		Body:        bytes.NewReader(data),
		ContentType: aws.String(contentType),
	}
	// ServerSideEncryption is AWS-S3-specific — only send it for real AWS
	// S3 (no custom endpoint), matching storage_service.py's identical
	// R2-compatibility guard.
	if cfg.S3EndpointURL == "" {
		input.ServerSideEncryption = "AES256"
	}
	_, err := client.PutObject(ctx, input)
	if err != nil {
		return "", err
	}
	return key, nil
}

func s3Download(ctx context.Context, key string) ([]byte, error) {
	cfg := config.Get()
	client, _ := getS3Client()
	out, err := client.GetObject(ctx, &s3.GetObjectInput{
		Bucket: aws.String(cfg.S3BucketName),
		Key:    aws.String(key),
	})
	if err != nil {
		return nil, err
	}
	defer out.Body.Close()
	return io.ReadAll(out.Body)
}

func s3PresignedURL(ctx context.Context, key string, expiresIn time.Duration) (string, error) {
	cfg := config.Get()
	_, presign := getS3Client()
	req, err := presign.PresignGetObject(ctx, &s3.GetObjectInput{
		Bucket: aws.String(cfg.S3BucketName),
		Key:    aws.String(key),
	}, s3.WithPresignExpires(expiresIn))
	if err != nil {
		return "", err
	}
	return req.URL, nil
}

// UploadBytes stores data under key, using S3/R2 or local disk depending
// on STORAGE_BACKEND.
func UploadBytes(ctx context.Context, data []byte, key, contentType string) (string, error) {
	if config.Get().StorageBackend == "s3" {
		return s3Upload(ctx, data, key, contentType)
	}
	return localUpload(data, key)
}

// DownloadBytes retrieves previously-uploaded data.
func DownloadBytes(ctx context.Context, key string) ([]byte, error) {
	if config.Get().StorageBackend == "s3" {
		return s3Download(ctx, key)
	}
	return localDownload(key)
}

// GetPresignedURL returns a time-limited download URL.
func GetPresignedURL(ctx context.Context, key string, expiresIn time.Duration) (string, error) {
	if config.Get().StorageBackend == "s3" {
		return s3PresignedURL(ctx, key, expiresIn)
	}
	return localPresignedURL(key)
}
