package integrations

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"
)

// RazorpayConnector implements DataConnector against Razorpay's real
// Settlements API (https://razorpay.com/docs/api/settlements/) — API-key
// authenticated (Basic Auth with key_id:key_secret), no OAuth. Each
// settlement is a single bulk bank deposit covering many individual
// payments; FetchTransactions returns one FetchedTransaction per
// settlement (the "bulk payout -> individual invoice" breakdown the
// user asked for happens on the reconciliation-matching side, same as
// any other bank credit — this connector's job is just getting the
// settlement amount and date into the system accurately).
type RazorpayConnector struct {
	client *http.Client
}

func NewRazorpayConnector() *RazorpayConnector {
	return &RazorpayConnector{client: &http.Client{Timeout: 20 * time.Second}}
}

func (c *RazorpayConnector) Provider() string { return "RAZORPAY" }

func (c *RazorpayConnector) Connect(ctx context.Context, credentials map[string]string) (string, string, error) {
	keyID, keySecret := credentials["key_id"], credentials["key_secret"]
	if keyID == "" || keySecret == "" {
		return "", "", fmt.Errorf("key_id and key_secret are required")
	}

	// Cheapest real call that proves the credentials work: fetch 1
	// settlement. Succeeds even for a brand-new account with zero
	// settlements yet (Razorpay returns an empty list, not an error).
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.razorpay.com/v1/settlements?count=1", nil)
	if err != nil {
		return "", "", err
	}
	req.SetBasicAuth(keyID, keySecret)

	resp, err := c.client.Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusUnauthorized {
		return "", "", fmt.Errorf("Razorpay rejected these credentials — check the key_id/key_secret")
	}
	if resp.StatusCode >= 400 {
		return "", "", fmt.Errorf("Razorpay API returned HTTP %d", resp.StatusCode)
	}

	// Razorpay's settlements endpoint doesn't return an account
	// name/ID directly; keyID (partial) is used as the display handle.
	displayID := keyID
	if len(displayID) > 12 {
		displayID = displayID[:12] + "…"
	}
	return keyID, displayID, nil
}

type razorpaySettlement struct {
	ID          string `json:"id"`
	Amount      int64  `json:"amount"` // paise
	Fees        int64  `json:"fees"`   // paise
	CreatedAt   int64  `json:"created_at"`
	Status      string `json:"status"`
	Description string `json:"description"`
}

func (c *RazorpayConnector) FetchTransactions(ctx context.Context, credentials map[string]string, sinceISO string) ([]FetchedTransaction, error) {
	keyID, keySecret := credentials["key_id"], credentials["key_secret"]

	url := "https://api.razorpay.com/v1/settlements?count=100"
	if sinceISO != "" {
		if t, err := time.Parse("2006-01-02", sinceISO); err == nil {
			url += "&from=" + strconv.FormatInt(t.Unix(), 10)
		}
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	req.SetBasicAuth(keyID, keySecret)

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("Razorpay settlements fetch failed: HTTP %d", resp.StatusCode)
	}

	var body struct {
		Items []razorpaySettlement `json:"items"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return nil, err
	}

	out := make([]FetchedTransaction, 0, len(body.Items))
	for _, s := range body.Items {
		if s.Status != "processed" {
			continue // only completed settlements represent real bank credits
		}
		out = append(out, FetchedTransaction{
			ExternalID: s.ID,
			Narration:  "Razorpay settlement " + s.ID,
			Date:       time.Unix(s.CreatedAt, 0).UTC().Format("2006-01-02"),
			Amount:     float64(s.Amount) / 100.0,
			Currency:   "INR",
			Fee:        float64(s.Fees) / 100.0,
		})
	}
	return out, nil
}
