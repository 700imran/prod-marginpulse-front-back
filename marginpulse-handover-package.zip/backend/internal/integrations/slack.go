package integrations

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"time"

	"github.com/marginpulse/backend/internal/platformsettings"
)

// NotifyConnector is implemented by providers we PUSH alerts to, rather
// than pull financial data from — Slack doesn't hold transaction
// records, so it doesn't implement DataConnector.
type NotifyConnector interface {
	Provider() string
	AuthURL(state string) string
	ExchangeCode(ctx context.Context, code string) (accessToken, teamName, incomingWebhookURL string, err error)
	SendNotification(ctx context.Context, webhookURL, message string) error
}

// SlackConnector implements NotifyConnector via Slack's real OAuth v2 +
// "Incoming Webhooks" feature — used to push reconciliation alerts
// (e.g. "3 new GST mismatches found") into a tenant's chosen Slack
// channel, requested as one of the "business tools" integrations.
type SlackConnector struct {
	client *http.Client
}

func NewSlackConnector() *SlackConnector {
	return &SlackConnector{client: &http.Client{Timeout: 15 * time.Second}}
}

func (c *SlackConnector) Provider() string { return "SLACK" }

func (c *SlackConnector) AuthURL(ctx context.Context, state string) (string, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return "", err
	}
	v := url.Values{}
	v.Set("client_id", settings.SlackClientID)
	v.Set("scope", "incoming-webhook")
	v.Set("redirect_uri", settings.SlackRedirectURI)
	v.Set("state", state)
	return "https://slack.com/oauth/v2/authorize?" + v.Encode(), nil
}

func (c *SlackConnector) ExchangeCode(ctx context.Context, code string) (string, string, string, error) {
	settings, err := platformsettings.Get(ctx)
	if err != nil {
		return "", "", "", err
	}

	form := url.Values{}
	form.Set("client_id", settings.SlackClientID)
	form.Set("client_secret", settings.SlackClientSecret)
	form.Set("code", code)
	form.Set("redirect_uri", settings.SlackRedirectURI)

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://slack.com/api/oauth.v2.access",
		bytes.NewReader([]byte(form.Encode())))
	if err != nil {
		return "", "", "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp, err := c.client.Do(req)
	if err != nil {
		return "", "", "", err
	}
	defer resp.Body.Close()

	var body struct {
		OK          bool   `json:"ok"`
		Error       string `json:"error"`
		AccessToken string `json:"access_token"`
		Team        struct {
			Name string `json:"name"`
		} `json:"team"`
		IncomingWebhook struct {
			URL     string `json:"url"`
			Channel string `json:"channel"`
		} `json:"incoming_webhook"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return "", "", "", err
	}
	if !body.OK {
		return "", "", "", fmt.Errorf("slack oauth failed: %s", body.Error)
	}
	return body.AccessToken, body.Team.Name, body.IncomingWebhook.URL, nil
}

func (c *SlackConnector) SendNotification(ctx context.Context, webhookURL, message string) error {
	payload, _ := json.Marshal(map[string]string{"text": message})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, webhookURL, bytes.NewReader(payload))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return fmt.Errorf("slack webhook send failed: HTTP %d", resp.StatusCode)
	}
	return nil
}
