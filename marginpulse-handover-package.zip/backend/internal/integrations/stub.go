package integrations

// NOT IMPLEMENTED — documents exactly what's needed to add each of
// these, so a future engineer (or a future session) can add one in an
// afternoon by following an existing connector as the template, rather
// than needing to design the plumbing from scratch.
//
// Why these aren't faked with mock data: this is a financial
// reconciliation product. A "connector" that silently returns made-up
// transactions would produce wrong reconciliation results that LOOK
// correct — worse than no integration at all. Every connector in this
// package (Razorpay, Stripe, Slack) calls a real provider API and fails
// loudly if credentials don't work.
//
// ── API-KEY connectors (implement DataConnector, see razorpay.go) ──────
//   - PayPal Payouts:      GET https://api-m.paypal.com/v1/reporting/transactions
//                          (OAuth2 client-credentials grant, not user-redirect —
//                          closer to an API-key flow than a login flow)
//   - Square:              GET https://connect.squareup.com/v2/payments
//                          (Bearer access token from Square's own dashboard)
//   - Tally (local network): Tally's ODBC/XML gateway runs on the
//                          user's own LAN (http://localhost:9000 by
//                          default) — this backend, running in AWS
//                          Lambda, CANNOT reach a machine on someone's
//                          office network at all. A Tally integration
//                          needs a small locally-run agent (a tiny
//                          background app the tenant installs) that
//                          polls Tally locally and pushes data up to
//                          this API — a materially different
//                          architecture from every other connector here,
//                          not just a new file.
//
// ── OAUTH connectors (implement DataConnector + AuthURL/ExchangeCode,
//    see internal/oauth/google.go for the pattern) ──────────────────────
//   - QuickBooks Online:   https://developer.intuit.com/app/developer/qbo/docs/get-started
//   - Xero:                https://developer.xero.com/documentation/guides/oauth2/auth-flow/
//   - HubSpot CRM:         https://developers.hubspot.com/docs/api/oauth-quickstart-guide
//   - Salesforce:          https://help.salesforce.com/s/articleView?id=sf.remoteaccess_oauth_web_server_flow.htm
//
// ── ENTERPRISE / PARTNERSHIP-GATED (code alone is not sufficient) ──────
//   - SAP ERP, Oracle NetSuite: these typically require a formal ISV
//     partnership/certification with the vendor before sandbox API
//     access is even granted — budget for a business-development
//     process, not just an engineering one, before starting this.
