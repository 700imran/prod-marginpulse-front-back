package integrations

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"
)

// StripeConnector implements DataConnector against Stripe's real Payouts
// API (https://stripe.com/docs/api/payouts) — API-key authenticated
// (Bearer secret key), no OAuth needed for reading your own account's
// payout data. Stripe Connect's OAuth flow (for a platform managing
// OTHER businesses' Stripe accounts) is a different, larger feature not
// implemented here — this connector is for a single business reading
// its own payouts, which is what "cross-border transaction data" for
// GST reconciliation actually needs.
type StripeConnector struct {
	client *http.Client
}

func NewStripeConnector() *StripeConnector {
	return &StripeConnector{client: &http.Client{Timeout: 20 * time.Second}}
}

func (c *StripeConnector) Provider() string { return "STRIPE" }

func (c *StripeConnector) Connect(ctx context.Context, credentials map[string]string) (string, string, error) {
	secretKey := credentials["secret_key"]
	if secretKey == "" {
		return "", "", fmt.Errorf("secret_key is required")
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://api.stripe.com/v1/account", nil)
	if err != nil {
		return "", "", err
	}
	req.Header.Set("Authorization", "Bearer "+secretKey)

	resp, err := c.client.Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()

	if resp.StatusCode == http.StatusUnauthorized {
		return "", "", fmt.Errorf("Stripe rejected this secret key")
	}
	if resp.StatusCode >= 400 {
		return "", "", fmt.Errorf("Stripe API returned HTTP %d", resp.StatusCode)
	}

	var account struct {
		ID           string `json:"id"`
		BusinessName string `json:"business_name"`
		Email        string `json:"email"`
		DisplayName  string `json:"display_name"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&account); err != nil {
		return "", "", err
	}
	name := account.BusinessName
	if name == "" {
		name = account.DisplayName
	}
	if name == "" {
		name = account.Email
	}
	return account.ID, name, nil
}

type stripePayout struct {
	ID          string `json:"id"`
	Amount      int64  `json:"amount"` // smallest currency unit (cents/paise)
	Currency    string `json:"currency"`
	Status      string `json:"status"`
	Arrived     int64  `json:"arrival_date"`
	Description string `json:"description"`
}

func (c *StripeConnector) FetchTransactions(ctx context.Context, credentials map[string]string, sinceISO string) ([]FetchedTransaction, error) {
	secretKey := credentials["secret_key"]

	apiURL := "https://api.stripe.com/v1/payouts?limit=100"
	if sinceISO != "" {
		if t, err := time.Parse("2006-01-02", sinceISO); err == nil {
			apiURL += "&arrival_date[gte]=" + strconv.FormatInt(t.Unix(), 10)
		}
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, apiURL, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+secretKey)

	resp, err := c.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("Stripe payouts fetch failed: HTTP %d", resp.StatusCode)
	}

	var body struct {
		Data []stripePayout `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return nil, err
	}

	out := make([]FetchedTransaction, 0, len(body.Data))
	for _, p := range body.Data {
		if p.Status != "paid" {
			continue
		}
		out = append(out, FetchedTransaction{
			ExternalID: p.ID,
			Narration:  "Stripe payout " + p.ID,
			Date:       time.Unix(p.Arrived, 0).UTC().Format("2006-01-02"),
			Amount:     float64(p.Amount) / 100.0,
			Currency:   currencyUpper(p.Currency),
		})
	}
	return out, nil
}

func currencyUpper(c string) string {
	out := make([]byte, len(c))
	for i := 0; i < len(c); i++ {
		ch := c[i]
		if ch >= 'a' && ch <= 'z' {
			ch -= 'a' - 'A'
		}
		out[i] = ch
	}
	return string(out)
}
