// Package integrations implements the third-party business-tool
// connectors (payment gateways, CRM/ERP, team communication) that plug
// into the generic repository.IntegrationsRepo storage layer.
//
// TWO CONNECTOR SHAPES, because the real providers split cleanly into
// two authentication styles:
//
//  1. API-KEY connectors (Razorpay, Stripe, Square in most integrations,
//     Tally's local API): the tenant pastes a key/secret pair they
//     generated in that provider's own dashboard. No redirect flow —
//     Connect() just verifies the key works and stores it encrypted.
//     Implement DataConnector for these (see razorpay.go, stripe.go).
//
//  2. OAUTH connectors (Slack, QuickBooks Online, Xero, HubSpot,
//     Salesforce, PayPal's own OAuth, Stripe Connect): the tenant is
//     redirected to the provider to approve access, same shape as the
//     Google/Apple login flows in internal/oauth. Implement
//     NotifyConnector (see slack.go) or a data-fetching equivalent.
//
// STATUS OF EACH PROVIDER — read before wiring one into a live account:
//   - Razorpay: FULLY IMPLEMENTED, calls the real Settlements API.
//   - Stripe:   FULLY IMPLEMENTED, calls the real Payouts API.
//   - Slack:    FULLY IMPLEMENTED OAuth connect + incoming webhook
//     notification send (for reconciliation alerts) — not a data-fetch
//     connector, since Slack doesn't hold financial data to pull.
//   - PayPal, Square, Notion, QuickBooks, Xero, Tally, HubSpot,
//     Salesforce, SAP, NetSuite: NOT implemented. See stub.go for
//     exactly what each would need — a real developer account and, for
//     SAP/NetSuite, a vendor partnership, not just code. Deliberately
//     not mocked: a fake connector that "succeeds" with fabricated
//     transaction data would produce wrong reconciliation results that
//     look correct, which is worse than no button at all in a financial
//     product.
package integrations

import "context"

// DataConnector is implemented by providers we pull financial records
// from (Razorpay, Stripe) — the fetched records feed into the same
// reconciliation pipeline as a bank statement CSV upload.
type DataConnector interface {
	Provider() string
	// Connect verifies the given credentials actually work (a real,
	// cheap API call) before anything is stored — never store a
	// credential we haven't confirmed is valid.
	Connect(ctx context.Context, credentials map[string]string) (externalAccountID, externalAccountName string, err error)
	// FetchTransactions pulls recent settlement/payout records and
	// returns them in the same shape reconciliation already understands.
	FetchTransactions(ctx context.Context, credentials map[string]string, sinceISO string) ([]FetchedTransaction, error)
}

// FetchedTransaction is the common shape every DataConnector normalizes
// into — deliberately identical in spirit to
// repository.CreateBankTransactionInput, since a Razorpay settlement or
// a Stripe payout both ultimately become one more "money that arrived"
// row for the reconciliation engine to match against invoices.
type FetchedTransaction struct {
	ExternalID string
	Narration  string
	Date       string // ISO "YYYY-MM-DD"
	Amount     float64
	Currency   string
	Fee        float64 // gateway processing fee, if broken out separately
}
