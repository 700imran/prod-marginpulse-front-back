// Package dashboard builds the product's default daily dashboard — the
// business-insight view the roadmap asked for, on top of (not instead
// of) the plain mismatch list already served by
// HandleDashboardSummary. Where that endpoint answers "what didn't
// match", this package answers "what should I actually do today":
// which ITC is most at risk, which vendors need a nudge, and which GST
// filing deadline is coming up.
package dashboard

import (
	"context"
	"sort"
	"strings"
	"time"

	"github.com/marginpulse/backend/internal/repository"
)

// ITCRiskItem is one document contributing to blocked Input Tax
// Credit right now — the "highest ITC risk today" list.
type ITCRiskItem struct {
	DocumentID    string  `json:"document_id"`
	VendorName    string  `json:"vendor_name"`
	InvoiceNumber string  `json:"invoice_number,omitempty"`
	TaxAmount     float64 `json:"tax_amount"`
	Reason        string  `json:"reason"`
}

// VendorFollowUp aggregates every open ITC-risk document by vendor —
// the "vendors requiring follow-up" list, so the owner works vendor by
// vendor rather than invoice by invoice.
type VendorFollowUp struct {
	VendorName     string   `json:"vendor_name"`
	TotalTaxAtRisk float64  `json:"total_tax_at_risk"`
	OpenIssueCount int      `json:"open_issue_count"`
	Reasons        []string `json:"reasons"`
}

// FilingDeadline is one upcoming statutory GST return due date.
// DueDate/Period follow the standard monthly-filer calendar (GSTR-1 by
// the 11th, GSTR-3B by the 20th of the following month) — this doesn't
// yet account for QRMP quarterly filers or state-specific staggered
// GSTR-3B due dates (22nd/24th); see the handover notes.
type FilingDeadline struct {
	ReturnType    string `json:"return_type"`
	Period        string `json:"period"`
	DueDate       string `json:"due_date"`
	DaysRemaining int    `json:"days_remaining"`
	Approaching   bool   `json:"approaching"`
}

// BusinessInsights is the full response for GET /dashboard/insights.
type BusinessInsights struct {
	HighestITCRiskToday      []ITCRiskItem    `json:"highest_itc_risk_today"`
	VendorsRequiringFollowUp []VendorFollowUp `json:"vendors_requiring_follow_up"`
	FilingDeadlines          []FilingDeadline `json:"filing_deadlines"`
	EstimatedRecoverableITC  float64          `json:"estimated_recoverable_itc"`
	GeneratedAt              string           `json:"generated_at"`
}

// maxListItems caps each list so the dashboard stays a "what to do
// today" shortlist, not a full data dump — the CSV export and the
// anomalies list already cover the exhaustive view.
const maxListItems = 10

// Build assembles the business-insight dashboard for one tenant. It
// deliberately reuses the same GST-status signal
// (NOT_FILED / MISMATCH documents) that HandleDashboardSummary already
// reads — same underlying data, reshaped for "what should I do today"
// rather than "what's the raw count".
func Build(ctx context.Context, tenantID string) (BusinessInsights, error) {
	docsRepo := repository.NewDocumentsRepo()

	notFiled, err := docsRepo.ListByGSTStatus(ctx, tenantID, "NOT_FILED")
	if err != nil {
		return BusinessInsights{}, err
	}
	mismatch, err := docsRepo.ListByGSTStatus(ctx, tenantID, "MISMATCH")
	if err != nil {
		return BusinessInsights{}, err
	}

	var riskItems []ITCRiskItem
	vendorTotals := map[string]*VendorFollowUp{}
	var recoverable float64

	addDoc := func(d repository.DocumentItem, reason string) {
		recoverable += d.TaxAmount
		riskItems = append(riskItems, ITCRiskItem{
			DocumentID: d.DocumentID, VendorName: d.VendorName, InvoiceNumber: d.InvoiceNumber,
			TaxAmount: d.TaxAmount, Reason: reason,
		})
		key := strings.ToLower(strings.TrimSpace(d.VendorName))
		if key == "" {
			return
		}
		vf, ok := vendorTotals[key]
		if !ok {
			vf = &VendorFollowUp{VendorName: d.VendorName}
			vendorTotals[key] = vf
		}
		vf.TotalTaxAtRisk += d.TaxAmount
		vf.OpenIssueCount++
		vf.Reasons = append(vf.Reasons, reason)
	}
	for _, d := range notFiled {
		addDoc(d, "Vendor hasn't filed this invoice on the GST portal yet")
	}
	for _, d := range mismatch {
		addDoc(d, "Invoice details don't match what's on the GST portal")
	}

	sort.Slice(riskItems, func(i, j int) bool { return riskItems[i].TaxAmount > riskItems[j].TaxAmount })
	if len(riskItems) > maxListItems {
		riskItems = riskItems[:maxListItems]
	}

	vendors := make([]VendorFollowUp, 0, len(vendorTotals))
	for _, v := range vendorTotals {
		vendors = append(vendors, *v)
	}
	sort.Slice(vendors, func(i, j int) bool { return vendors[i].TotalTaxAtRisk > vendors[j].TotalTaxAtRisk })
	if len(vendors) > maxListItems {
		vendors = vendors[:maxListItems]
	}

	return BusinessInsights{
		HighestITCRiskToday:      riskItems,
		VendorsRequiringFollowUp: vendors,
		FilingDeadlines:          computeFilingDeadlines(time.Now().UTC()),
		EstimatedRecoverableITC:  recoverable,
		GeneratedAt:              time.Now().UTC().Format(time.RFC3339),
	}, nil
}

// approachingWithinDays controls the "approaching" flag — 7 days gives
// an owner a full week's notice to chase vendors before a deadline.
const approachingWithinDays = 7

func computeFilingDeadlines(today time.Time) []FilingDeadline {
	nextOccurrence := func(dayOfMonth int) time.Time {
		candidate := time.Date(today.Year(), today.Month(), dayOfMonth, 0, 0, 0, 0, time.UTC)
		if candidate.Before(today) {
			candidate = candidate.AddDate(0, 1, 0)
		}
		return candidate
	}
	build := func(returnType string, dayOfMonth int) FilingDeadline {
		due := nextOccurrence(dayOfMonth)
		periodBeingFiled := due.AddDate(0, -1, 0)
		daysRemaining := int(due.Sub(today).Hours() / 24)
		return FilingDeadline{
			ReturnType:    returnType,
			Period:        periodBeingFiled.Format("January 2006"),
			DueDate:       due.Format("2006-01-02"),
			DaysRemaining: daysRemaining,
			Approaching:   daysRemaining <= approachingWithinDays,
		}
	}
	return []FilingDeadline{
		build("GSTR-1", 11),
		build("GSTR-3B", 20),
	}
}
