// Package insights ports app/pipelines/insights_generator.py. There is
// no official Anthropic Go SDK, so this calls the /v1/messages REST
// endpoint directly via net/http + encoding/json — a small, auditable
// ~40-line client rather than a third-party dependency for a single
// endpoint call.
package insights

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"github.com/marginpulse/backend/internal/aibudget"
	"github.com/marginpulse/backend/internal/config"
)

const systemPrompt = `You are a plain-English financial summariser for small business owners.
Your job is to convert raw reconciliation data into a single, clear, jargon-free paragraph
(2-4 sentences max) that a non-accountant can understand immediately.

Rules:
- Never use accounting jargon (ledger, debit, credit, reconciliation, etc.)
- Always mention specific vendor names and rupee amounts where available
- If GST credits are at risk, state the exact INR amount blocked
- Be direct and actionable — end with what the owner should do next
- Keep under 80 words total
- Output ONLY the summary paragraph, no preamble or formatting`

// SummaryData mirrors the dashboard's summary_data dict.
type SummaryData struct {
	TotalUploadedDocuments        int
	SuccessfullyReconciledCount   int
	UnreconciledAnomaliesDetected int
	GSTMismatchFlagCount          int
	ITCAtRisk                     float64
	GSTProblemVendors             []string
	AnomalyBreakdown              map[string]int
	Period                        string
}

var httpClient = &http.Client{Timeout: 30 * time.Second}

// GenerateInsight mirrors generate_insight() — falls back to the
// deterministic rule-based summary if ANTHROPIC_API_KEY is unset OR the
// tenant has exceeded its AI rate limit / daily token budget.
func GenerateInsight(ctx context.Context, data SummaryData, tenantID string) string {
	cfg := config.Get()
	if cfg.AnthropicAPIKey == "" {
		return ruleBasedInsight(data)
	}

	if tenantID != "" {
		allowed, reason := aibudget.CheckBudget(ctx, tenantID)
		if !allowed {
			slog.Warn("ai_budget_exceeded", "tenant_id", tenantID, "reason", reason)
			return ruleBasedInsight(data)
		}
	}

	period := data.Period
	if period == "" {
		period = "current period"
	}
	vendorsJSON, _ := json.Marshal(data.GSTProblemVendors)
	breakdownJSON, _ := json.Marshal(data.AnomalyBreakdown)

	userMessage := fmt.Sprintf(`Here is the reconciliation data for this period:

Total documents processed: %d
Successfully matched: %d
Unresolved anomalies: %d
GST portal mismatches: %d
ITC amount at risk (INR): %.2f
Vendors with GST issues: %s
Anomaly types: %s
Period: %s

Write the plain-English summary.`,
		data.TotalUploadedDocuments, data.SuccessfullyReconciledCount, data.UnreconciledAnomaliesDetected,
		data.GSTMismatchFlagCount, data.ITCAtRisk, string(vendorsJSON), string(breakdownJSON), period,
	)

	maxPromptChars := cfg.AIMaxPromptTokens * 4
	if len(userMessage) > maxPromptChars {
		userMessage = userMessage[:maxPromptChars]
	}

	maxTokens := cfg.LLMMaxTokens
	if cfg.AIMaxCompletionTokens < maxTokens {
		maxTokens = cfg.AIMaxCompletionTokens
	}

	text, usage, err := callAnthropic(ctx, cfg, userMessage, maxTokens)
	if err != nil {
		slog.Error("anthropic API error in insights generator", "error", err)
		return ruleBasedInsight(data)
	}
	if tenantID != "" && usage > 0 {
		aibudget.RecordUsage(ctx, tenantID, usage)
	}
	return strings.TrimSpace(text)
}

type anthropicRequest struct {
	Model     string             `json:"model"`
	MaxTokens int                `json:"max_tokens"`
	System    string             `json:"system"`
	Messages  []anthropicMessage `json:"messages"`
}

type anthropicMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type anthropicResponse struct {
	Content []struct {
		Text string `json:"text"`
	} `json:"content"`
	Usage struct {
		InputTokens  int `json:"input_tokens"`
		OutputTokens int `json:"output_tokens"`
	} `json:"usage"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

func callAnthropic(ctx context.Context, cfg *config.Settings, userMessage string, maxTokens int) (string, int, error) {
	reqBody := anthropicRequest{
		Model:     cfg.LLMModel,
		MaxTokens: maxTokens,
		System:    systemPrompt,
		Messages:  []anthropicMessage{{Role: "user", Content: userMessage}},
	}
	payload, err := json.Marshal(reqBody)
	if err != nil {
		return "", 0, err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://api.anthropic.com/v1/messages", bytes.NewReader(payload))
	if err != nil {
		return "", 0, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", cfg.AnthropicAPIKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	resp, err := httpClient.Do(req)
	if err != nil {
		return "", 0, err
	}
	defer resp.Body.Close()

	var out anthropicResponse
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return "", 0, err
	}
	if resp.StatusCode >= 400 {
		msg := fmt.Sprintf("HTTP %d", resp.StatusCode)
		if out.Error != nil {
			msg = out.Error.Message
		}
		return "", 0, fmt.Errorf("anthropic API error: %s", msg)
	}
	if len(out.Content) == 0 {
		return "", 0, fmt.Errorf("anthropic API returned no content")
	}
	return out.Content[0].Text, out.Usage.InputTokens + out.Usage.OutputTokens, nil
}

// ruleBasedInsight mirrors _rule_based_insight() exactly.
func ruleBasedInsight(data SummaryData) string {
	total := data.TotalUploadedDocuments
	matched := data.SuccessfullyReconciledCount
	anomalies := data.UnreconciledAnomaliesDetected
	gstGaps := data.GSTMismatchFlagCount
	itcRisk := data.ITCAtRisk
	vendors := data.GSTProblemVendors

	matchPct := 0
	if total > 0 {
		matchPct = int(float64(matched)/float64(total)*100 + 0.5)
	}

	vendorStr := "some vendors"
	if len(vendors) > 0 {
		n := 2
		if len(vendors) < n {
			n = len(vendors)
		}
		vendorStr = strings.Join(vendors[:n], " and ")
	}

	switch {
	case gstGaps > 0:
		entryWord := "entries"
		if gstGaps == 1 {
			entryWord = "entry"
		}
		haveWord := "haven't"
		invoiceWord := "their invoices"
		if len(vendors) == 1 {
			haveWord = "hasn't"
			invoiceWord = "their invoice"
		}
		return fmt.Sprintf(
			"Your cash flow is matching cleanly at %d%% (%d of %d documents), except for %d supplier %s. "+
				"%s %s filed %s on the GST Portal yet, blocking ₹%s in Input Tax Credits. "+
				"Send them a reminder to file immediately.",
			matchPct, matched, total, gstGaps, entryWord, vendorStr, haveWord, invoiceWord, formatINR(itcRisk),
		)
	case anomalies > 0:
		return fmt.Sprintf(
			"Good news — %d%% of your transactions matched automatically this period. "+
				"There are %d items that need your review, likely due to amount variances "+
				"or timing differences with your bank. Check the flagged rows to clear them.",
			matchPct, anomalies,
		)
	default:
		return fmt.Sprintf(
			"Everything is clean — all %d transactions matched perfectly this period. "+
				"No GST issues or payment anomalies detected. You're all set.",
			total,
		)
	}
}

// formatINR renders a whole-rupee amount with thousands separators.
func formatINR(amount float64) string {
	whole := int64(amount + 0.5)
	s := fmt.Sprintf("%d", whole)
	neg := false
	if strings.HasPrefix(s, "-") {
		neg = true
		s = s[1:]
	}
	var out []byte
	for i, c := range []byte(s) {
		if i > 0 && (len(s)-i)%3 == 0 {
			out = append(out, ',')
		}
		out = append(out, c)
	}
	result := string(out)
	if neg {
		result = "-" + result
	}
	return result
}

// GenerateCollectionScript mirrors generate_collection_script() exactly.
func GenerateCollectionScript(vendorName, invoiceNumber string, amount float64, invoiceDate, issueType string) string {
	amountStr := formatINRDecimal(amount)
	switch issueType {
	case "GST_PORTAL_MISMATCH", "":
		return fmt.Sprintf(
			"Hi %s team,\n\nI wanted to follow up regarding invoice %s dated %s for ₹%s. "+
				"This invoice has not yet appeared on our GSTR-2B portal for the current period, "+
				"which is currently blocking our Input Tax Credit claim.\n\n"+
				"Could you please file this at the earliest convenience? "+
				"This will help both of us close our GST reconciliation on time.\n\n"+
				"Thank you for your prompt attention.",
			vendorName, invoiceNumber, invoiceDate, amountStr,
		)
	case "OVERDUE_PAYMENT":
		return fmt.Sprintf(
			"Hi %s team,\n\nThis is a gentle reminder that invoice %s for ₹%s issued on %s appears to be outstanding in our records.\n\n"+
				"Please let us know if you have any questions or if payment has already been arranged. "+
				"You can settle via the payment link attached.\n\nThank you.",
			vendorName, invoiceNumber, amountStr, invoiceDate,
		)
	default:
		return fmt.Sprintf(
			"Hi %s team,\n\nWe noticed a discrepancy in invoice %s (₹%s, %s). "+
				"Could you please review and confirm the details? We'd like to reconcile this promptly.\n\nThank you.",
			vendorName, invoiceNumber, amountStr, invoiceDate,
		)
	}
}

func formatINRDecimal(amount float64) string {
	whole := formatINR(amount)
	cents := int(amount*100+0.5) % 100
	if cents < 0 {
		cents = -cents
	}
	return fmt.Sprintf("%s.%02d", whole, cents)
}
