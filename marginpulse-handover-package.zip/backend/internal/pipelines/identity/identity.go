// Package identity ports app/pipelines/identity_verification.py — calls
// external GSTIN/PAN/bank-account verification APIs when configured,
// falling back to a PENDING status (not an error) when they aren't, so
// the app remains fully usable without paid verification API access
// during development or a bootstrapped early stage.
package identity

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/marginpulse/backend/internal/config"
)

type Result struct {
	Status       string // VERIFIED | FAILED | PENDING
	Error        string
	LegalName    string
	VerifiedName string // used by bank account verification
}

var httpClient = &http.Client{Timeout: 15 * time.Second}

// VerifyGSTIN calls the configured GST verification API. Falls back to
// PENDING (with an explanatory error message, not a hard failure) if
// GST_API_CLIENT_ID isn't configured — mirrors the Python version's
// graceful-degradation behavior exactly.
func VerifyGSTIN(ctx context.Context, gstin string) Result {
	cfg := config.Get()
	if cfg.GSTAPIClientID == "" {
		return Result{Status: "PENDING", Error: "GST verification API not configured — verify manually"}
	}

	url := fmt.Sprintf("%s/gstin/%s", cfg.GSTAPIBaseURL, gstin)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return Result{Status: "FAILED", Error: err.Error()}
	}
	req.Header.Set("client-id", cfg.GSTAPIClientID)
	req.Header.Set("client-secret", cfg.GSTAPIClientSecret)

	resp, err := httpClient.Do(req)
	if err != nil {
		return Result{Status: "FAILED", Error: fmt.Sprintf("GST portal request failed: %v", err)}
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return Result{Status: "FAILED", Error: fmt.Sprintf("GST portal returned HTTP %d", resp.StatusCode)}
	}

	var body struct {
		LegalName   string `json:"lgnm"`
		TradeName   string `json:"tradeNam"`
		GSTINStatus string `json:"sts"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return Result{Status: "FAILED", Error: "could not parse GST portal response"}
	}
	if body.GSTINStatus != "" && body.GSTINStatus != "Active" {
		return Result{Status: "FAILED", Error: fmt.Sprintf("GSTIN status is %q, not Active", body.GSTINStatus)}
	}

	legalName := body.LegalName
	if legalName == "" {
		legalName = body.TradeName
	}
	return Result{Status: "VERIFIED", LegalName: legalName}
}

// VerifyPAN calls the configured PAN verification API, comparing the
// returned legal name against the label the tenant provided (best-effort
// match) — same PENDING fallback as VerifyGSTIN.
func VerifyPAN(ctx context.Context, pan, expectedName string) Result {
	cfg := config.Get()
	if cfg.GSTAPIClientID == "" {
		return Result{Status: "PENDING", Error: "PAN verification API not configured — verify manually"}
	}

	url := fmt.Sprintf("%s/pan/%s", cfg.GSTAPIBaseURL, pan)
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return Result{Status: "FAILED", Error: err.Error()}
	}
	req.Header.Set("client-id", cfg.GSTAPIClientID)
	req.Header.Set("client-secret", cfg.GSTAPIClientSecret)

	resp, err := httpClient.Do(req)
	if err != nil {
		return Result{Status: "FAILED", Error: fmt.Sprintf("PAN verification request failed: %v", err)}
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return Result{Status: "FAILED", Error: fmt.Sprintf("PAN verification API returned HTTP %d", resp.StatusCode)}
	}

	var body struct {
		FullName string `json:"full_name"`
		Valid    bool   `json:"valid"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return Result{Status: "FAILED", Error: "could not parse PAN verification response"}
	}
	if !body.Valid {
		return Result{Status: "FAILED", Error: "PAN reported as invalid"}
	}
	return Result{Status: "VERIFIED", LegalName: body.FullName}
}

// VerifyBankAccount calls the configured penny-drop / account-validation
// API. Same PENDING fallback when unconfigured.
func VerifyBankAccount(ctx context.Context, accountNumber, ifscCode, accountHolderName string) Result {
	cfg := config.Get()
	if cfg.GSTAPIClientID == "" {
		return Result{Status: "PENDING", Error: "Bank account verification API not configured — verify manually"}
	}

	url := fmt.Sprintf("%s/bank-account/verify", cfg.GSTAPIBaseURL)
	payload, _ := json.Marshal(map[string]string{
		"account_number": accountNumber,
		"ifsc":           ifscCode,
	})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(payload))
	if err != nil {
		return Result{Status: "FAILED", Error: err.Error()}
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("client-id", cfg.GSTAPIClientID)
	req.Header.Set("client-secret", cfg.GSTAPIClientSecret)

	resp, err := httpClient.Do(req)
	if err != nil {
		return Result{Status: "FAILED", Error: fmt.Sprintf("bank verification request failed: %v", err)}
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return Result{Status: "FAILED", Error: fmt.Sprintf("bank verification API returned HTTP %d", resp.StatusCode)}
	}

	var body struct {
		AccountExists bool   `json:"account_exists"`
		HolderName    string `json:"name_at_bank"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return Result{Status: "FAILED", Error: "could not parse bank verification response"}
	}
	if !body.AccountExists {
		return Result{Status: "FAILED", Error: "account not found / IFSC mismatch"}
	}
	return Result{Status: "VERIFIED", VerifiedName: body.HolderName}
}
