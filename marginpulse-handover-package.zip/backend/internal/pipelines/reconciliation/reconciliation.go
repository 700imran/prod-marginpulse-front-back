// Package reconciliation ports app/pipelines/reconciliation_engine.py —
// the Section 2.3 composite matching score formula:
//
//	S_match = w1*L(s_inv,s_bank) + w2*(1-|v_inv-v_bank|/v_inv) + w3*exp(-λ*|t_inv-t_bank|)
//
// RUST_CORE_ENABLED is always false in this port (see config.go) — the
// Python version's Rust/PyO3 fast path was an optimization for 500+ row
// batches; Go's native performance for this same string/numeric work is
// already fast enough (compiled, no interpreter overhead) that a
// separate native-code escape hatch isn't needed here. Levenshtein
// distance is implemented directly (see levenshtein.go) rather than via
// a third-party fuzzy-matching library, mirroring rapidfuzz's exact
// algorithm with zero added dependencies.
package reconciliation

import (
	"fmt"
	"math"
	"strings"

	"github.com/marginpulse/backend/internal/config"
)

const (
	w1     = 0.40 // string similarity weight
	w2     = 0.40 // value match weight
	w3     = 0.20 // temporal proximity weight
	lambda = 0.15 // temporal decay factor
)

// LevenshteinRatio mirrors rapidfuzz's Levenshtein.distance-based ratio:
// 1.0 - (edit_distance / max_len), case-insensitive, whitespace-trimmed.
func LevenshteinRatio(a, b string) float64 {
	a = strings.ToLower(strings.TrimSpace(a))
	b = strings.ToLower(strings.TrimSpace(b))
	if a == "" || b == "" {
		return 0.0
	}
	dist := levenshteinDistance(a, b)
	maxLen := len(a)
	if len(b) > maxLen {
		maxLen = len(b)
	}
	if maxLen == 0 {
		return 1.0
	}
	return 1.0 - float64(dist)/float64(maxLen)
}

// levenshteinDistance is the classic dynamic-programming edit distance,
// operating on runes (not bytes) so it's correct for non-ASCII vendor
// names too — rapidfuzz operates on Python strings (already
// codepoint-aware), so this matches that behavior rather than Go's
// byte-string default.
func levenshteinDistance(a, b string) int {
	ra, rb := []rune(a), []rune(b)
	la, lb := len(ra), len(rb)
	if la == 0 {
		return lb
	}
	if lb == 0 {
		return la
	}
	prev := make([]int, lb+1)
	curr := make([]int, lb+1)
	for j := 0; j <= lb; j++ {
		prev[j] = j
	}
	for i := 1; i <= la; i++ {
		curr[0] = i
		for j := 1; j <= lb; j++ {
			cost := 1
			if ra[i-1] == rb[j-1] {
				cost = 0
			}
			del := prev[j] + 1
			ins := curr[j-1] + 1
			sub := prev[j-1] + cost
			m := del
			if ins < m {
				m = ins
			}
			if sub < m {
				m = sub
			}
			curr[j] = m
		}
		prev, curr = curr, prev
	}
	return prev[lb]
}

// DayDelta returns the absolute number of days between two dates given
// as "YYYY-MM-DD" ISO strings — matching (inv_date - bank_date).days.
func dayDelta(aISO, bISO string) (int, bool) {
	a, errA := parseISODate(aISO)
	b, errB := parseISODate(bISO)
	if errA != nil || errB != nil {
		return 0, false
	}
	diff := a.Sub(b).Hours() / 24
	if diff < 0 {
		diff = -diff
	}
	return int(diff + 0.5), true
}

// ComputeMatchScore mirrors compute_match_score() exactly.
func ComputeMatchScore(invVendor, bankNarration string, invAmount, bankAmount float64, invDateISO, bankDateISO string) float64 {
	stringScore := LevenshteinRatio(invVendor, bankNarration)

	var valueScore float64
	if invAmount > 0 {
		valueDiffRatio := math.Abs(invAmount-bankAmount) / invAmount
		valueScore = math.Max(0.0, 1.0-valueDiffRatio)
	}

	days, ok := dayDelta(invDateISO, bankDateISO)
	temporalScore := 0.0
	if ok {
		temporalScore = math.Exp(-lambda * float64(days))
	}

	score := w1*stringScore + w2*valueScore + w3*temporalScore
	if score > 1.0 {
		score = 1.0
	}
	return roundTo6(score)
}

func roundTo6(f float64) float64 {
	return math.Round(f*1_000_000) / 1_000_000
}

// Invoice and BankRow are the plain data shapes reconcile_batch operates
// on — equivalent to the Python version's dict-keyed inputs, but typed.
type Invoice struct {
	DocumentID     string
	VendorName     string
	RawTotalAmount float64
	DocumentDate   string // ISO "YYYY-MM-DD"
}

type BankRow struct {
	TransactionID   string
	Narration       string
	DebitAmount     float64
	TransactionDate string // ISO "YYYY-MM-DD"
}

type MatchResult struct {
	DocumentID               string
	MatchedBankTransactionID string // "" if none
	Score                    float64
	Status                   string // RECONCILED | MANUAL_REVIEW | UNMATCHED | FAILED
	Reason                   string
}

// ReconcileBatch mirrors reconcile_batch() — for each invoice, finds the
// best-scoring bank transaction and classifies by confidence threshold.
func ReconcileBatch(invoices []Invoice, bankRows []BankRow) []MatchResult {
	cfg := config.Get()
	results := make([]MatchResult, 0, len(invoices))

	for _, inv := range invoices {
		if inv.DocumentDate == "" || inv.RawTotalAmount == 0 {
			results = append(results, MatchResult{
				DocumentID: inv.DocumentID,
				Score:      0.0,
				Status:     "FAILED",
				Reason:     "Missing amount or date for matching",
			})
			continue
		}

		bestScore := 0.0
		bestMatchID := ""
		bestNarration := ""
		for _, bank := range bankRows {
			if bank.TransactionDate == "" || bank.DebitAmount == 0 {
				continue
			}
			score := ComputeMatchScore(inv.VendorName, bank.Narration, inv.RawTotalAmount, bank.DebitAmount, inv.DocumentDate, bank.TransactionDate)
			if score > bestScore {
				bestScore = score
				bestMatchID = bank.TransactionID
				bestNarration = bank.Narration
			}
		}

		var status, reason string
		switch {
		case bestScore >= cfg.ReconcileAutoApproveThreshold:
			status = "RECONCILED"
			reason = fmt.Sprintf("Matched bank transaction %q with confidence %.0f%% (>= %.0f%% auto-approve threshold)",
				bestNarration, bestScore*100, cfg.ReconcileAutoApproveThreshold*100)
		case bestScore >= cfg.ReconcileConfidenceThreshold:
			status = "MANUAL_REVIEW"
			reason = fmt.Sprintf("Best candidate bank transaction %q scored %.0f%% — above the %.0f%% review floor but below the %.0f%% auto-approve threshold, so needs a human check",
				bestNarration, bestScore*100, cfg.ReconcileConfidenceThreshold*100, cfg.ReconcileAutoApproveThreshold*100)
		case bestMatchID != "":
			status = "UNMATCHED"
			reason = fmt.Sprintf("Closest bank transaction %q only scored %.0f%% (below the %.0f%% review floor) — vendor name, amount, or date likely don't line up",
				bestNarration, bestScore*100, cfg.ReconcileConfidenceThreshold*100)
		default:
			status = "UNMATCHED"
			reason = "No bank transaction found within the search window with a matching debit amount"
		}

		matchedID := ""
		if status == "RECONCILED" {
			matchedID = bestMatchID
		}
		results = append(results, MatchResult{
			DocumentID:               inv.DocumentID,
			MatchedBankTransactionID: matchedID,
			Score:                    bestScore,
			Status:                   status,
			Reason:                   reason,
		})
	}
	return results
}
