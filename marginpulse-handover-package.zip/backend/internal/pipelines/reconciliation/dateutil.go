package reconciliation

import "time"

// parseISODate parses a "YYYY-MM-DD" date string, also tolerating a full
// RFC3339 timestamp (truncating to the date portion) since some callers
// may pass a stored created_at-style value by mistake — being lenient
// here avoids a silent FAILED match result over a formatting nuance.
func parseISODate(s string) (time.Time, error) {
	if t, err := time.Parse("2006-01-02", s); err == nil {
		return t, nil
	}
	return time.Parse(time.RFC3339, s)
}
