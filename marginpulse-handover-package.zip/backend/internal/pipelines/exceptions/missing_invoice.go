// Package exceptions holds detection heuristics that don't belong to a
// single document or bank transaction upload flow — currently just
// missing-invoice detection, run on demand via
// POST /api/v1/reconciliation/detect-missing-invoices (see
// internal/httpapi/reconciliation_handlers.go's
// HandleDetectMissingInvoices). Kept separate from the reconciliation
// package since this operates on the *absence* of a matching invoice
// rather than scoring two records against each other.
package exceptions

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"github.com/marginpulse/backend/internal/pipelines/reconciliation"
	"github.com/marginpulse/backend/internal/repository"
)

// vendorNarrationMatchThreshold is deliberately looser than the
// reconciliation engine's own thresholds — this is a "does this look
// like it's probably vendor X" heuristic to flag for human review, not
// an auto-match, so a lower bar (catching more true positives at the
// cost of a few false ones a human can dismiss in one click) is the
// right tradeoff here.
const vendorNarrationMatchThreshold = 0.55

// olderThanDays is how long a bank debit must have sat UNMATCHED before
// it's treated as a possible missing invoice rather than "still waiting
// on OCR/reconciliation to catch up".
const olderThanDays = 5

// Result summarizes one detection run for the HTTP handler's response.
type Result struct {
	BankTransactionsScanned int
	AnomaliesCreated        int
}

// DetectMissingInvoices scans this tenant's UNMATCHED bank debits older
// than olderThanDays, fuzzy-matches each narration against every vendor
// name the tenant has ever uploaded an invoice for, and raises a
// MISSING_INVOICE anomaly (skipping any transaction that already has an
// open one) when a plausible vendor match is found.
func DetectMissingInvoices(ctx context.Context, tenantID string) (Result, error) {
	docsRepo := repository.NewDocumentsRepo()
	txnRepo := repository.NewBankTransactionsRepo()
	anomaliesRepo := repository.NewAnomaliesRepo()
	auditRepo := repository.NewAuditLogsRepo()

	vendorNames, err := docsRepo.ListVendorNames(ctx, tenantID)
	if err != nil {
		return Result{}, err
	}
	if len(vendorNames) == 0 {
		return Result{}, nil
	}

	cutoff := time.Now().UTC().AddDate(0, 0, -olderThanDays).Format("2006-01-02")
	// Wide lower bound — ListUnmatchedInDateRange needs an explicit
	// start; "0000-01-01" is before any real bank statement, so this
	// effectively means "everything unmatched up to the cutoff".
	txns, err := txnRepo.ListUnmatchedInDateRange(ctx, tenantID, "0000-01-01", cutoff)
	if err != nil {
		return Result{}, err
	}

	res := Result{BankTransactionsScanned: len(txns)}
	for _, txn := range txns {
		if txn.DebitAmount == 0 {
			continue // only debits (money going out) look like vendor payments
		}
		bestVendor := ""
		bestScore := 0.0
		for _, vendor := range vendorNames {
			score := reconciliation.LevenshteinRatio(vendor, txn.Narration)
			if score > bestScore {
				bestScore = score
				bestVendor = vendor
			}
		}
		if bestScore < vendorNarrationMatchThreshold {
			continue
		}

		alreadyFlagged, err := anomaliesRepo.ExistsOpenForRelatedTransaction(ctx, tenantID, txn.TransactionID)
		if err != nil {
			slog.Error("missing_invoice_existing_check_failed", "transaction_id", txn.TransactionID, "error", err)
			continue
		}
		if alreadyFlagged {
			continue
		}

		description := fmt.Sprintf("Bank debit of %.2f on %s (%q) looks like a payment to %s, but no matching invoice has been uploaded",
			txn.DebitAmount, txn.TransactionDate, txn.Narration, bestVendor)
		if _, err := anomaliesRepo.Create(ctx, repository.CreateAnomalyInput{
			TenantID: tenantID, RelatedTransactionID: txn.TransactionID, AnomalyType: "MISSING_INVOICE",
			Severity: "MEDIUM", Description: description,
			SuggestedAction: fmt.Sprintf("Upload the invoice from %s for this payment, or mark it as not requiring one", bestVendor),
		}); err != nil {
			slog.Error("missing_invoice_anomaly_create_failed", "transaction_id", txn.TransactionID, "error", err)
			continue
		}
		if _, err := auditRepo.Create(ctx, repository.CreateAuditLogInput{
			TenantID: tenantID, EntityType: "BANKTXN", EntityID: txn.TransactionID,
			Action: "MISSING_INVOICE_DETECTED", Reason: description,
		}); err != nil {
			slog.Error("missing_invoice_audit_log_failed", "transaction_id", txn.TransactionID, "error", err)
		}
		res.AnomaliesCreated++
	}
	return res, nil
}
