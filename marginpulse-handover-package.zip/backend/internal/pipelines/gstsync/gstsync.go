// Package gstsync ports app/pipelines/gst_sync.py — fetches GSTR-2B from
// the NIC GST API and cross-verifies internal vendor records against it.
package gstsync

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/marginpulse/backend/internal/config"
)

type PortalClient struct {
	authToken string
	mu        sync.Mutex
	client    *http.Client
}

func NewPortalClient() *PortalClient {
	return &PortalClient{client: &http.Client{Timeout: 60 * time.Second}}
}

func (c *PortalClient) getAuthToken(ctx context.Context) (string, error) {
	cfg := config.Get()
	payload, _ := json.Marshal(map[string]string{
		"username":      cfg.GSTAPIUsername,
		"client_id":     cfg.GSTAPIClientID,
		"client_secret": cfg.GSTAPIClientSecret,
	})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, cfg.GSTAPIBaseURL+"/authenticate", bytes.NewReader(payload))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return "", fmt.Errorf("GST auth failed: HTTP %d", resp.StatusCode)
	}

	var body struct {
		AuthToken string `json:"auth_token"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return "", err
	}
	c.mu.Lock()
	c.authToken = body.AuthToken
	c.mu.Unlock()
	return body.AuthToken, nil
}

// FetchGSTR2B fetches GSTR-2B JSON for the given GSTIN and period
// (MMYYYY format), retrying once on a 401 (expired token) — mirrors
// GSTPortalClient.fetch_gstr2b() exactly.
func (c *PortalClient) FetchGSTR2B(ctx context.Context, gstin, returnPeriod string) (map[string]interface{}, error) {
	cfg := config.Get()

	c.mu.Lock()
	token := c.authToken
	c.mu.Unlock()
	if token == "" {
		var err error
		token, err = c.getAuthToken(ctx)
		if err != nil {
			return nil, err
		}
	}

	doFetch := func(tok string) (*http.Response, error) {
		url := fmt.Sprintf("%s/returns/gstr2b?gstin=%s&ret_period=%s&day_limit=30", cfg.GSTAPIBaseURL, gstin, returnPeriod)
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
		if err != nil {
			return nil, err
		}
		req.Header.Set("auth-token", tok)
		return c.client.Do(req)
	}

	resp, err := doFetch(token)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode == http.StatusUnauthorized {
		resp.Body.Close()
		token, err = c.getAuthToken(ctx)
		if err != nil {
			return nil, err
		}
		resp, err = doFetch(token)
		if err != nil {
			return nil, err
		}
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("GSTR-2B fetch failed: HTTP %d", resp.StatusCode)
	}

	var result map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return result, nil
}

// SupplierInvoice mirrors one entry in parse_gstr2b_suppliers()'s
// "invoices" list.
type SupplierInvoice struct {
	InvoiceNumber string
	InvoiceDate   string
	TaxableValue  float64
	IGST          float64
	CGST          float64
	SGST          float64
}

type Supplier struct {
	TradeName string
	Invoices  []SupplierInvoice
}

// ParseGSTR2BSuppliers mirrors parse_gstr2b_suppliers() — flattens the
// GSTR-2B response into a map keyed by supplier GSTIN.
func ParseGSTR2BSuppliers(gstr2bJSON map[string]interface{}) map[string]Supplier {
	result := map[string]Supplier{}

	data, _ := gstr2bJSON["data"].(map[string]interface{})
	if data == nil {
		return result
	}
	docData, _ := data["docdata"].(map[string]interface{})
	if docData == nil {
		return result
	}
	b2bEntries, _ := docData["b2b"].([]interface{})

	for _, raw := range b2bEntries {
		supplier, ok := raw.(map[string]interface{})
		if !ok {
			continue
		}
		gstin := strings.ToUpper(asString(supplier["ctin"]))
		if gstin == "" {
			continue
		}
		var invoices []SupplierInvoice
		invRaw, _ := supplier["inv"].([]interface{})
		for _, ir := range invRaw {
			inv, ok := ir.(map[string]interface{})
			if !ok {
				continue
			}
			invoices = append(invoices, SupplierInvoice{
				InvoiceNumber: asString(inv["inum"]),
				InvoiceDate:   asString(inv["idt"]),
				TaxableValue:  asFloat(inv["txval"]),
				IGST:          asFloat(inv["igst"]),
				CGST:          asFloat(inv["cgst"]),
				SGST:          asFloat(inv["sgst"]),
			})
		}
		result[gstin] = Supplier{TradeName: asString(supplier["trdnm"]), Invoices: invoices}
	}
	return result
}

func asString(v interface{}) string {
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

func asFloat(v interface{}) float64 {
	switch n := v.(type) {
	case float64:
		return n
	case int:
		return float64(n)
	default:
		return 0
	}
}

// InternalVendor mirrors cross_verify_vendors()'s internal_vendors input.
type InternalVendor struct {
	DocumentID     string
	VendorName     string
	TaxIdentifier  string // GSTIN
	RawTotalAmount float64
	InvoiceNumber  string
}

// VerificationResult mirrors one entry of cross_verify_vendors()'s output.
type VerificationResult struct {
	DocumentID      string
	GSTPortalStatus string // PENDING | NOT_FILED | MISMATCH | FILED
	ITCRisk         float64
	Note            string
}

// CrossVerifyVendors mirrors cross_verify_vendors() exactly, including
// its status decision tree (no GSTIN -> PENDING; GSTIN not in portal ->
// NOT_FILED; GSTIN filed but this invoice number missing -> MISMATCH;
// both present -> FILED).
func CrossVerifyVendors(internalVendors []InternalVendor, portalSuppliers map[string]Supplier) []VerificationResult {
	results := make([]VerificationResult, 0, len(internalVendors))

	for _, vendor := range internalVendors {
		gstin := strings.ToUpper(strings.TrimSpace(vendor.TaxIdentifier))
		if gstin == "" {
			results = append(results, VerificationResult{
				DocumentID:      vendor.DocumentID,
				GSTPortalStatus: "PENDING",
				ITCRisk:         vendor.RawTotalAmount,
				Note:            "No GSTIN extracted from invoice",
			})
			continue
		}

		supplier, found := portalSuppliers[gstin]
		if !found {
			results = append(results, VerificationResult{
				DocumentID:      vendor.DocumentID,
				GSTPortalStatus: "NOT_FILED",
				ITCRisk:         vendor.RawTotalAmount,
				Note:            fmt.Sprintf("GSTIN %s not found in GSTR-2B for this period", gstin),
			})
			continue
		}

		portalInvoiceNumbers := map[string]bool{}
		for _, inv := range supplier.Invoices {
			portalInvoiceNumbers[inv.InvoiceNumber] = true
		}

		if vendor.InvoiceNumber != "" && !portalInvoiceNumbers[vendor.InvoiceNumber] {
			results = append(results, VerificationResult{
				DocumentID:      vendor.DocumentID,
				GSTPortalStatus: "MISMATCH",
				ITCRisk:         vendor.RawTotalAmount,
				Note:            fmt.Sprintf("Invoice %s not found in GSTR-2B although supplier GSTIN is filed", vendor.InvoiceNumber),
			})
		} else {
			results = append(results, VerificationResult{
				DocumentID:      vendor.DocumentID,
				GSTPortalStatus: "FILED",
				ITCRisk:         0,
				Note:            "Verified on GST portal",
			})
		}
	}
	return results
}
