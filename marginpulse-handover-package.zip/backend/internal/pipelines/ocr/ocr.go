// Package ocr ports the document data-extraction step — invokes the
// RapidOCR Python Lambda (../../../ocr-service) via AWS Lambda's Invoke
// API for raw text detection, then applies the same regex-based
// structured-field extraction (vendor/amount/date/GSTIN/invoice number)
// as before. REPLACES the earlier tesseract/pdftoppm os/exec approach,
// which hit real dnf/al2023 base-image compatibility problems in
// practice (30+ minute stalled installs) — see cmd/worker/Dockerfile's
// comment for the full story.
//
// PDF handling: rather than reaching for a paid cloud OCR service
// (AWS Textract, Google Document AI, etc.) as a PDF-vs-image workaround,
// PDF pages are rasterized to images INSIDE ocr-service itself using
// PyMuPDF (pip-installable, no system packages, no per-page cloud
// cost — the same "pip install, no dnf" reliability property that
// fixed the original tesseract problem). This Go file just tells the
// Lambda what mime type it's sending; ocr-service/handler.py decides
// whether to rasterize first.
package ocr

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"sync"

	"github.com/aws/aws-sdk-go-v2/aws"
	awsconfig "github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/lambda"

	"github.com/marginpulse/backend/internal/config"
)

type Result struct {
	OCRAvailable   bool
	VendorName     string
	DocumentDate   string // ISO "YYYY-MM-DD", "" if not found
	RawTotalAmount float64
	TaxAmount      float64
	TaxIdentifier  string
	InvoiceNumber  string
	RawText        string
	Confidence     float64
}

var (
	amountPatterns = []*regexp.Regexp{
		regexp.MustCompile(`(?i)(?:total|grand\s*total|amount\s*due|net\s*payable)[^\d]*?([\d,]+\.?\d*)`),
		regexp.MustCompile(`(?i)(?:₹|rs\.?|inr)\s*([\d,]+\.?\d*)`),
		regexp.MustCompile(`([\d,]{4,}\.?\d{0,2})`),
	}
	gstinPattern    = regexp.MustCompile(`\b([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1})\b`)
	datePatternDMY  = regexp.MustCompile(`(\d{2})[/-](\d{2})[/-](\d{4})`)
	datePatternYMD  = regexp.MustCompile(`(\d{4})[/-](\d{2})[/-](\d{2})`)
	taxPattern      = regexp.MustCompile(`(?i)(?:cgst|sgst|igst|gst|tax)[^\d]*([\d,]+\.?\d*)`)
	invoicePattern  = regexp.MustCompile(`(?i)(?:invoice|inv)[^\w]*([\w/-]+)`)
	invoiceHeaderRe = regexp.MustCompile(`(?i)invoice|receipt|bill|tax\s*invoice`)
	startsWithDigit = regexp.MustCompile(`^\d`)
)

var (
	lambdaClientOnce sync.Once
	lambdaClient     *lambda.Client
)

func getLambdaClient() *lambda.Client {
	lambdaClientOnce.Do(func() {
		cfg := config.Get()
		ctx := context.Background()
		optFns := []func(*awsconfig.LoadOptions) error{awsconfig.WithRegion(cfg.AWSRegion)}
		if cfg.AWSAccessKeyID != "" {
			optFns = append(optFns, awsconfig.WithCredentialsProvider(
				credentials.NewStaticCredentialsProvider(cfg.AWSAccessKeyID, cfg.AWSSecretKey, ""),
			))
		}
		awsCfg, err := awsconfig.LoadDefaultConfig(ctx, optFns...)
		if err != nil {
			panic(fmt.Sprintf("failed to load AWS config for Lambda client: %v", err))
		}
		lambdaClient = lambda.NewFromConfig(awsCfg)
	})
	return lambdaClient
}

// ocrLambdaRequest's MimeType tells ocr-service/handler.py whether to
// rasterize first (PDF) or run RapidOCR directly (image) — see
// handler.py's own contract comment.
type ocrLambdaRequest struct {
	FileBase64 string `json:"file_base64"`
	MimeType   string `json:"mime_type"`
}

type ocrLambdaLine struct {
	Text       string  `json:"text"`
	Confidence float64 `json:"confidence"`
}

type ocrLambdaResponse struct {
	Lines []ocrLambdaLine `json:"lines"`
	Error string          `json:"error"`
}

// invokeOCRLambda calls the RapidOCR Python Lambda (ocr-service/handler.py)
// synchronously and returns the detected text lines with per-line
// confidence — a real invocation of RapidOCR's own tested pipeline, not
// a from-scratch Go reimplementation of its detection/recognition logic.
func invokeOCRLambda(ctx context.Context, fileBytes []byte, mimeType string) (*ocrLambdaResponse, error) {
	cfg := config.Get()
	payload, err := json.Marshal(ocrLambdaRequest{
		FileBase64: base64.StdEncoding.EncodeToString(fileBytes),
		MimeType:   mimeType,
	})
	if err != nil {
		return nil, err
	}

	out, err := getLambdaClient().Invoke(ctx, &lambda.InvokeInput{
		FunctionName: aws.String(cfg.OCRLambdaFunctionName),
		Payload:      payload,
	})
	if err != nil {
		return nil, fmt.Errorf("OCR Lambda invocation failed: %w", err)
	}
	if out.FunctionError != nil {
		return nil, fmt.Errorf("OCR Lambda returned an error: %s: %s", *out.FunctionError, string(out.Payload))
	}

	var resp ocrLambdaResponse
	if err := json.Unmarshal(out.Payload, &resp); err != nil {
		return nil, fmt.Errorf("could not parse OCR Lambda response: %w", err)
	}
	if resp.Error != "" {
		return nil, fmt.Errorf("OCR processing failed: %s", resp.Error)
	}
	return &resp, nil
}

func extractAmount(text string) (float64, bool) {
	for _, pat := range amountPatterns {
		if m := pat.FindStringSubmatch(text); m != nil {
			cleaned := strings.ReplaceAll(m[1], ",", "")
			if v, err := strconv.ParseFloat(cleaned, 64); err == nil {
				return v, true
			}
		}
	}
	return 0, false
}

func extractGSTIN(text string) string {
	if m := gstinPattern.FindStringSubmatch(text); m != nil {
		return m[1]
	}
	return ""
}

func extractDate(text string) string {
	if m := datePatternYMD.FindStringSubmatch(text); m != nil {
		if isValidDate(m[1], m[2], m[3]) {
			return fmt.Sprintf("%s-%s-%s", m[1], m[2], m[3])
		}
	}
	if m := datePatternDMY.FindStringSubmatch(text); m != nil {
		if isValidDate(m[3], m[2], m[1]) {
			return fmt.Sprintf("%s-%s-%s", m[3], m[2], m[1])
		}
	}
	return ""
}

func isValidDate(y, m, d string) bool {
	yi, e1 := strconv.Atoi(y)
	mi, e2 := strconv.Atoi(m)
	di, e3 := strconv.Atoi(d)
	if e1 != nil || e2 != nil || e3 != nil {
		return false
	}
	return yi >= 1900 && yi <= 2100 && mi >= 1 && mi <= 12 && di >= 1 && di <= 31
}

func extractVendor(text string) string {
	var lines []string
	for _, l := range strings.Split(text, "\n") {
		l = strings.TrimSpace(l)
		if l != "" {
			lines = append(lines, l)
		}
	}
	limit := 5
	if len(lines) < limit {
		limit = len(lines)
	}
	for _, line := range lines[:limit] {
		if len(line) > 5 && !startsWithDigit.MatchString(line) && !invoiceHeaderRe.MatchString(line) {
			if len(line) > 255 {
				return line[:255]
			}
			return line
		}
	}
	if len(lines) > 0 {
		if len(lines[0]) > 255 {
			return lines[0][:255]
		}
		return lines[0]
	}
	return ""
}

func unavailableResult() Result {
	return Result{OCRAvailable: false}
}

// ProcessDocument invokes the RapidOCR Lambda and applies the same
// regex-based structured-field extraction the earlier tesseract-based
// version used. mimeType is forwarded to ocr-service, which rasterizes
// PDF pages with PyMuPDF before running RapidOCR on them — see the
// package doc comment for why that lives there instead of a paid cloud
// OCR call.
func ProcessDocument(ctx context.Context, fileBytes []byte, mimeType string) (Result, error) {
	resp, err := invokeOCRLambda(ctx, fileBytes, mimeType)
	if err != nil {
		return Result{}, err
	}

	var textBuilder strings.Builder
	var confidenceSum float64
	for _, line := range resp.Lines {
		textBuilder.WriteString(line.Text)
		textBuilder.WriteString("\n")
		confidenceSum += line.Confidence
	}
	rawText := textBuilder.String()

	avgConfidence := 0.0
	if len(resp.Lines) > 0 {
		avgConfidence = confidenceSum / float64(len(resp.Lines))
	}

	totalAmount, _ := extractAmount(rawText)
	gstin := extractGSTIN(rawText)
	vendor := extractVendor(rawText)
	docDate := extractDate(rawText)

	var taxAmount float64
	if m := taxPattern.FindStringSubmatch(rawText); m != nil {
		if v, err := strconv.ParseFloat(strings.ReplaceAll(m[1], ",", ""), 64); err == nil {
			taxAmount = v
		}
	}

	var invoiceNumber string
	if m := invoicePattern.FindStringSubmatch(rawText); m != nil {
		invoiceNumber = m[1]
		if len(invoiceNumber) > 128 {
			invoiceNumber = invoiceNumber[:128]
		}
	}

	truncatedText := rawText
	if len(truncatedText) > 5000 {
		truncatedText = truncatedText[:5000]
	}

	return Result{
		OCRAvailable:   true,
		VendorName:     vendor,
		DocumentDate:   docDate,
		RawTotalAmount: totalAmount,
		TaxAmount:      taxAmount,
		TaxIdentifier:  gstin,
		InvoiceNumber:  invoiceNumber,
		RawText:        truncatedText,
		Confidence:     roundTo4(avgConfidence),
	}, nil
}

func roundTo4(f float64) float64 {
	return float64(int(f*10000+0.5)) / 10000
}
