package repository

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

type TeamMembersRepo struct{ client *dynamodb.Client }

func NewTeamMembersRepo() *TeamMembersRepo { return &TeamMembersRepo{client: db.Client()} }

func GenerateInviteToken() string {
	b := make([]byte, 48)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}

func (r *TeamMembersRepo) GetByID(ctx context.Context, tenantID, teamMemberID string) (*TeamMemberItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.TeamMemberSK(teamMemberID)},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, ErrNotFound
	}
	var item TeamMemberItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TeamMembersRepo) GetByInviteToken(ctx context.Context, token string) (*TeamMemberItem, error) {
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI3"),
		KeyConditionExpression: aws.String("gsi3pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.TeamMemberGSI3PKInvite(token)},
		},
		Limit: aws.Int32(1),
	})
	if err != nil {
		return nil, err
	}
	if len(out.Items) == 0 {
		return nil, ErrNotFound
	}
	var item TeamMemberItem
	if err := attributevalue.UnmarshalMap(out.Items[0], &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TeamMembersRepo) ListByTenant(ctx context.Context, tenantID string) ([]TeamMemberItem, error) {
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "TEAMMEMBER#"},
		},
	})
	if err != nil {
		return nil, err
	}
	items := make([]TeamMemberItem, 0, len(out.Items))
	for _, raw := range out.Items {
		var m TeamMemberItem
		if err := attributevalue.UnmarshalMap(raw, &m); err != nil {
			return nil, err
		}
		items = append(items, m)
	}
	sortByCreatedAtDesc(items, func(m TeamMemberItem) string { return m.InvitedAt })
	return items, nil
}

func (r *TeamMembersRepo) CountActiveOrPending(ctx context.Context, tenantID string) (int, error) {
	all, err := r.ListByTenant(ctx, tenantID)
	if err != nil {
		return 0, err
	}
	n := 0
	for _, m := range all {
		if m.Status == "PENDING" || m.Status == "ACTIVE" {
			n++
		}
	}
	return n, nil
}

func (r *TeamMembersRepo) FindActiveOrPendingForEmail(ctx context.Context, tenantID, email string) (*TeamMemberItem, error) {
	all, err := r.ListByTenant(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	for _, m := range all {
		if m.InvitedEmail == email && (m.Status == "PENDING" || m.Status == "ACTIVE") {
			return &m, nil
		}
	}
	return nil, ErrNotFound
}

type CreateTeamMemberInput struct {
	TenantID     string
	InvitedEmail string
	Role         string
}

func (r *TeamMembersRepo) Create(ctx context.Context, in CreateTeamMemberInput) (*TeamMemberItem, error) {
	teamMemberID := uuid.NewString()
	inviteToken := GenerateInviteToken()
	now := nowISO()
	role := in.Role
	if role == "" {
		role = "VIEWER"
	}
	item := TeamMemberItem{
		PK:           db.TenantPK(in.TenantID),
		SK:           db.TeamMemberSK(teamMemberID),
		GSI3PK:       db.TeamMemberGSI3PKInvite(inviteToken),
		GSI3SK:       db.TeamMemberSK(teamMemberID),
		TeamMemberID: teamMemberID,
		TenantID:     in.TenantID,
		InvitedEmail: in.InvitedEmail,
		Role:         role,
		Status:       "PENDING",
		InviteToken:  inviteToken,
		InvitedAt:    now,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TeamMembersRepo) UpdateFields(ctx context.Context, tenantID, teamMemberID string, updates []FieldUpdate) (*TeamMemberItem, error) {
	setParts := []string{}
	removeParts := []string{}
	names := map[string]string{}
	values := map[string]types.AttributeValue{}

	for _, u := range updates {
		namePh := "#" + u.Name
		names[namePh] = u.Name
		if u.Value == nil {
			removeParts = append(removeParts, namePh)
			continue
		}
		av, err := attributevalue.Marshal(u.Value)
		if err != nil {
			return nil, err
		}
		valPh := ":" + u.Name
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
	}

	expr := ""
	if len(setParts) > 0 {
		expr += "SET " + strings.Join(setParts, ", ")
	}
	if len(removeParts) > 0 {
		if expr != "" {
			expr += " "
		}
		expr += "REMOVE " + strings.Join(removeParts, ", ")
	}

	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.TeamMemberSK(teamMemberID)},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item TeamMemberItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}
