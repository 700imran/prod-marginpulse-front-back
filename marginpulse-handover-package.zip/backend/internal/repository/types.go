// Package repository ports app/repositories/*.py — one file per entity,
// using github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue's
// struct-tag-based marshaling instead of Python's manual dict
// construction. This is a genuine improvement over the Python version:
// `dynamodbav` struct tags declare each field's DynamoDB attribute name
// and `omitempty` behavior once, in one place, instead of every
// repository function needing its own `strip_none({...})` call — the
// compiler catches a typo'd field name that Python could only catch at
// runtime.
package repository

import "time"

// TenantItem is the DynamoDB item shape for TENANT#<id> / METADATA.
type TenantItem struct {
	PK     string `dynamodbav:"pk"`
	SK     string `dynamodbav:"sk"`
	GSI1PK string `dynamodbav:"gsi1pk,omitempty"`
	GSI1SK string `dynamodbav:"gsi1sk,omitempty"`
	GSI2PK string `dynamodbav:"gsi2pk,omitempty"`
	GSI2SK string `dynamodbav:"gsi2sk,omitempty"`
	GSI3PK string `dynamodbav:"gsi3pk,omitempty"`
	GSI3SK string `dynamodbav:"gsi3sk,omitempty"`

	TenantID             string `dynamodbav:"tenant_id"`
	BusinessName         string `dynamodbav:"business_name"`
	DisplayName          string `dynamodbav:"display_name,omitempty"`
	OwnerEmail           string `dynamodbav:"owner_email"`
	HashedPassword       string `dynamodbav:"hashed_password"`
	PhoneNumber          string `dynamodbav:"phone_number,omitempty"`
	CountryCode          string `dynamodbav:"country_code"`
	WhatsAppBindingPhone string `dynamodbav:"whatsapp_binding_phone,omitempty"`
	IngestEmailAlias     string `dynamodbav:"ingest_email_alias,omitempty"`
	GSTINNumber          string `dynamodbav:"gstin_number,omitempty"`
	GSTRegistered        bool   `dynamodbav:"gst_registered"`
	PlanTier             string `dynamodbav:"plan_tier"`
	IsActive             bool   `dynamodbav:"is_active"`
	// IsPlatformAdmin gates access to the platform admin panel (managing
	// ALL tenants, global feature flags, OAuth/integration provider
	// config) — a completely different scope from a tenant's own
	// TeamMember roles, which only ever govern access within that one
	// tenant's own data. Deliberately NOT self-service settable via any
	// API endpoint — the only way to become a platform admin is a
	// direct DynamoDB UpdateItem run by whoever operates the AWS
	// account (see ADMIN_PANEL.md), so a compromised tenant account can
	// never escalate itself into seeing every other customer's data.
	IsPlatformAdmin bool   `dynamodbav:"is_platform_admin,omitempty"`
	CreatedAt       string `dynamodbav:"created_at"`
	UpdatedAt       string `dynamodbav:"updated_at"`
}

// DocumentItem is the DynamoDB item shape for TENANT#<id> / DOCUMENT#<id>.
type DocumentItem struct {
	PK     string `dynamodbav:"pk"`
	SK     string `dynamodbav:"sk"`
	GSI1PK string `dynamodbav:"gsi1pk,omitempty"`
	GSI1SK string `dynamodbav:"gsi1sk,omitempty"`
	GSI2PK string `dynamodbav:"gsi2pk,omitempty"`
	GSI2SK string `dynamodbav:"gsi2sk,omitempty"`

	DocumentID               string  `dynamodbav:"document_id"`
	TenantID                 string  `dynamodbav:"tenant_id"`
	DocType                  string  `dynamodbav:"doc_type"`
	OriginalFilename         string  `dynamodbav:"original_filename"`
	S3Key                    string  `dynamodbav:"s3_key,omitempty"`
	MimeType                 string  `dynamodbav:"mime_type,omitempty"`
	FileSizeBytes            int64   `dynamodbav:"file_size_bytes,omitempty"`
	VendorName               string  `dynamodbav:"vendor_name,omitempty"`
	VendorAddress            string  `dynamodbav:"vendor_address,omitempty"`
	DocumentDate             string  `dynamodbav:"document_date,omitempty"`
	InvoiceNumber            string  `dynamodbav:"invoice_number,omitempty"`
	RawTotalAmount           float64 `dynamodbav:"raw_total_amount,omitempty"`
	SubtotalAmount           float64 `dynamodbav:"subtotal_amount,omitempty"`
	TaxAmount                float64 `dynamodbav:"tax_amount,omitempty"`
	Currency                 string  `dynamodbav:"currency"`
	TaxIdentifier            string  `dynamodbav:"tax_identifier,omitempty"`
	TaxType                  string  `dynamodbav:"tax_type,omitempty"`
	IngestChannel            string  `dynamodbav:"ingest_channel"`
	WhatsAppMessageID        string  `dynamodbav:"whatsapp_message_id,omitempty"`
	SenderPhone              string  `dynamodbav:"sender_phone,omitempty"`
	ProcessingStatus         string  `dynamodbav:"processing_status"`
	OCRConfidenceScore       float64 `dynamodbav:"ocr_confidence_score,omitempty"`
	ReconciliationScore      float64 `dynamodbav:"reconciliation_score,omitempty"`
	MatchedBankTransactionID string  `dynamodbav:"matched_bank_transaction_id,omitempty"`
	GSTPortalStatus          string  `dynamodbav:"gst_portal_status,omitempty"`
	JobID                    string  `dynamodbav:"job_id,omitempty"`
	OCRErrorMessage          string  `dynamodbav:"ocr_error_message,omitempty"`

	// ReconciliationReason is the human-readable evidence/exception
	// explanation for why this document ended up RECONCILED,
	// MANUAL_REVIEW, or UNMATCHED (see internal/pipelines/reconciliation
	// explainMatch) — surfaced in the document detail view, the CSV
	// export, and copied onto any anomaly created for this document.
	ReconciliationReason string `dynamodbav:"reconciliation_reason,omitempty"`

	// DuplicateOfDocumentID is set when duplicate-invoice detection (see
	// cmd/worker's checkForDuplicateInvoice) finds an existing document
	// for this tenant with the same vendor+invoice-number (or
	// vendor+amount+date) — non-empty means "treat this upload with
	// suspicion", not "reject it": the document is still kept and
	// reconciled normally, just flagged via an accompanying anomaly.
	DuplicateOfDocumentID string `dynamodbav:"duplicate_of_document_id,omitempty"`

	// Manual correction workflow fields — set by HandleCorrectDocument
	// whenever a user edits OCR/reconciliation output by hand. Every
	// such edit ALSO writes an AuditLogItem with the specific
	// before/after field diff; these three fields are just a cheap "was
	// this ever touched" flag for list/detail views.
	ManuallyCorrected bool   `dynamodbav:"manually_corrected,omitempty"`
	CorrectedBy       string `dynamodbav:"corrected_by,omitempty"`
	CorrectedAt       string `dynamodbav:"corrected_at,omitempty"`

	CreatedAt string `dynamodbav:"created_at"`
	UpdatedAt string `dynamodbav:"updated_at"`
}

// BankTransactionItem is the DynamoDB item shape for
// TENANT#<id> / BANKTXN#<date>#<id>.
type BankTransactionItem struct {
	PK     string `dynamodbav:"pk"`
	SK     string `dynamodbav:"sk"`
	GSI2PK string `dynamodbav:"gsi2pk,omitempty"`
	GSI2SK string `dynamodbav:"gsi2sk,omitempty"`

	TransactionID        string  `dynamodbav:"transaction_id"`
	TenantID             string  `dynamodbav:"tenant_id"`
	BankReference        string  `dynamodbav:"bank_reference,omitempty"`
	Narration            string  `dynamodbav:"narration"`
	TransactionDate      string  `dynamodbav:"transaction_date"`
	ValueDate            string  `dynamodbav:"value_date,omitempty"`
	DebitAmount          float64 `dynamodbav:"debit_amount,omitempty"`
	CreditAmount         float64 `dynamodbav:"credit_amount,omitempty"`
	ClosingBalance       float64 `dynamodbav:"closing_balance,omitempty"`
	Currency             string  `dynamodbav:"currency"`
	ReconciliationStatus string  `dynamodbav:"reconciliation_status"`
	MatchedDocumentID    string  `dynamodbav:"matched_document_id,omitempty"`
	MatchScore           float64 `dynamodbav:"match_score,omitempty"`
	SourceFilename       string  `dynamodbav:"source_filename,omitempty"`
	BankName             string  `dynamodbav:"bank_name,omitempty"`
	CreatedAt            string  `dynamodbav:"created_at"`
}

// TaxIdentifierItem is the DynamoDB item shape for TENANT#<id> / TAXID#<id>.
type TaxIdentifierItem struct {
	PK string `dynamodbav:"pk"`
	SK string `dynamodbav:"sk"`

	TaxIdentifierID      string `dynamodbav:"tax_identifier_id"`
	TenantID             string `dynamodbav:"tenant_id"`
	IDType               string `dynamodbav:"id_type"`
	IDValue              string `dynamodbav:"id_value"`
	Label                string `dynamodbav:"label,omitempty"`
	VerificationStatus   string `dynamodbav:"verification_status"`
	VerifiedAt           string `dynamodbav:"verified_at,omitempty"`
	VerificationError    string `dynamodbav:"verification_error,omitempty"`
	VerifiedLegalName    string `dynamodbav:"verified_legal_name,omitempty"`
	VerifiedMetadataJSON string `dynamodbav:"verified_metadata_json,omitempty"`
	IsPrimary            bool   `dynamodbav:"is_primary"`
	CreatedAt            string `dynamodbav:"created_at"`
	UpdatedAt            string `dynamodbav:"updated_at"`
}

// TaxIdentifierGuardItem is the uniqueness-guard item for
// TENANT#<id> / TAXID_GUARD#<type>#<value>.
type TaxIdentifierGuardItem struct {
	PK              string `dynamodbav:"pk"`
	SK              string `dynamodbav:"sk"`
	TaxIdentifierID string `dynamodbav:"tax_identifier_id"`
}

// BankAccountItem is the DynamoDB item shape for TENANT#<id> / BANKACCT#<id>.
type BankAccountItem struct {
	PK string `dynamodbav:"pk"`
	SK string `dynamodbav:"sk"`

	BankAccountID             string `dynamodbav:"bank_account_id"`
	TenantID                  string `dynamodbav:"tenant_id"`
	BankName                  string `dynamodbav:"bank_name"`
	AccountHolderName         string `dynamodbav:"account_holder_name"`
	AccountNumberEncrypted    string `dynamodbav:"account_number_encrypted"`
	AccountNumberLast4        string `dynamodbav:"account_number_last4"`
	IFSCCode                  string `dynamodbav:"ifsc_code"`
	AccountType               string `dynamodbav:"account_type"`
	VerificationStatus        string `dynamodbav:"verification_status"`
	VerifiedAt                string `dynamodbav:"verified_at,omitempty"`
	VerificationError         string `dynamodbav:"verification_error,omitempty"`
	VerifiedAccountHolderName string `dynamodbav:"verified_account_holder_name,omitempty"`
	IsPrimary                 bool   `dynamodbav:"is_primary"`
	CreatedAt                 string `dynamodbav:"created_at"`
	UpdatedAt                 string `dynamodbav:"updated_at"`
}

// TeamMemberItem is the DynamoDB item shape for TENANT#<id> / TEAMMEMBER#<id>.
type TeamMemberItem struct {
	PK     string `dynamodbav:"pk"`
	SK     string `dynamodbav:"sk"`
	GSI3PK string `dynamodbav:"gsi3pk,omitempty"`
	GSI3SK string `dynamodbav:"gsi3sk,omitempty"`

	TeamMemberID string `dynamodbav:"team_member_id"`
	TenantID     string `dynamodbav:"tenant_id"`
	InvitedEmail string `dynamodbav:"invited_email"`
	Role         string `dynamodbav:"role"`
	Status       string `dynamodbav:"status"`
	InviteToken  string `dynamodbav:"invite_token"`
	InvitedAt    string `dynamodbav:"invited_at"`
	AcceptedAt   string `dynamodbav:"accepted_at,omitempty"`
	RevokedAt    string `dynamodbav:"revoked_at,omitempty"`
}

// AnomalyItem is the DynamoDB item shape for TENANT#<id> / ANOMALY#<date>#<id>.
type AnomalyItem struct {
	PK string `dynamodbav:"pk"`
	SK string `dynamodbav:"sk"`

	AnomalyID  string `dynamodbav:"anomaly_id"`
	TenantID   string `dynamodbav:"tenant_id"`
	DocumentID string `dynamodbav:"document_id,omitempty"`
	// RelatedTransactionID holds a bank transaction ID for anomaly types
	// that key off a bank transaction rather than (or in addition to) a
	// document — currently just MISSING_INVOICE, raised against an
	// unmatched debit that looks like a recurring vendor payment. Kept
	// as a separate field rather than overloading DocumentID so a
	// MISSING_INVOICE anomaly can still reference a vendor name without
	// implying a document already exists.
	RelatedTransactionID string `dynamodbav:"related_transaction_id,omitempty"`
	AnomalyType          string `dynamodbav:"anomaly_type"`
	Severity             string `dynamodbav:"severity"`
	Description          string `dynamodbav:"description"`
	SuggestedAction      string `dynamodbav:"suggested_action,omitempty"`
	Status               string `dynamodbav:"status"`
	ResolvedAt           string `dynamodbav:"resolved_at,omitempty"`
	ResolvedBy           string `dynamodbav:"resolved_by,omitempty"`
	CreatedAt            string `dynamodbav:"created_at"`
}

// AuditLogItem is the DynamoDB item shape for
// TENANT#<id> / AUDITLOG#<created_at>#<id> — the complete audit trail
// backing the "who changed what, when, and why" requirement. Every
// manual correction, anomaly resolution, and automated exception
// (duplicate/missing invoice) writes one of these; nothing in this
// codebase ever mutates or deletes an AuditLogItem once written.
type AuditLogItem struct {
	PK string `dynamodbav:"pk"`
	SK string `dynamodbav:"sk"`

	AuditLogID string `dynamodbav:"audit_log_id"`
	TenantID   string `dynamodbav:"tenant_id"`
	// EntityType + EntityID identify what this log entry is about, e.g.
	// EntityType="DOCUMENT", EntityID=<document_id>. Kept as plain
	// strings (not a DynamoDB index) since audit history is read by
	// entity via a bounded per-tenant filter, same tradeoff as
	// anomalies.go's GetByID — acceptable at this app's audit-log volume.
	EntityType string `dynamodbav:"entity_type"`
	EntityID   string `dynamodbav:"entity_id"`
	Action     string `dynamodbav:"action"`
	// FieldName/OldValue/NewValue are populated for single-field-change
	// entries (manual corrections); left empty for entries describing an
	// action with no single before/after field (e.g. "ANOMALY_CREATED").
	FieldName  string `dynamodbav:"field_name,omitempty"`
	OldValue   string `dynamodbav:"old_value,omitempty"`
	NewValue   string `dynamodbav:"new_value,omitempty"`
	Reason     string `dynamodbav:"reason,omitempty"`
	ActorEmail string `dynamodbav:"actor_email,omitempty"`
	CreatedAt  string `dynamodbav:"created_at"`
}

// nowISO returns the current UTC time in RFC3339 (same format used
// throughout, equivalent to Python's datetime.now(timezone.utc).isoformat()).
func nowISO() string {
	return time.Now().UTC().Format(time.RFC3339)
}
