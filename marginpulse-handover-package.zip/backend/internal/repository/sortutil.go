package repository

import "sort"

// sortByCreatedAtDesc sorts any slice of items newest-first given a
// key-extraction function — used by repositories whose main-table Query
// doesn't naturally return date order (unlike Documents' GSI1, whose
// gsi1sk already embeds created_at).
func sortByCreatedAtDesc[T any](items []T, createdAt func(T) string) {
	sort.Slice(items, func(i, j int) bool { return createdAt(items[i]) > createdAt(items[j]) })
}
