package repository

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"

	"github.com/marginpulse/backend/internal/db"
)

// PlatformSettingsItem is a SINGLE item (pk="PLATFORM", sk="SETTINGS")
// shared across the whole deployment, not per-tenant — this is what the
// admin panel edits so OAuth/integration credentials and feature flags
// can be changed without touching Lambda environment variables or
// redeploying. Every field here has a matching env-var default (see
// internal/platformsettings/platformsettings.go's merge logic) so a
// fresh deployment works from .env alone before anyone has ever opened
// the admin panel.
type PlatformSettingsItem struct {
	PK string `dynamodbav:"pk"`
	SK string `dynamodbav:"sk"`

	GoogleClientID        string `dynamodbav:"google_client_id,omitempty"`
	GoogleClientSecretEnc string `dynamodbav:"google_client_secret_enc,omitempty"`
	GoogleRedirectURI     string `dynamodbav:"google_redirect_uri,omitempty"`

	AppleClientID      string `dynamodbav:"apple_client_id,omitempty"`
	AppleTeamID        string `dynamodbav:"apple_team_id,omitempty"`
	AppleKeyID         string `dynamodbav:"apple_key_id,omitempty"`
	ApplePrivateKeyEnc string `dynamodbav:"apple_private_key_enc,omitempty"`
	AppleRedirectURI   string `dynamodbav:"apple_redirect_uri,omitempty"`

	SlackClientID        string `dynamodbav:"slack_client_id,omitempty"`
	SlackClientSecretEnc string `dynamodbav:"slack_client_secret_enc,omitempty"`
	SlackRedirectURI     string `dynamodbav:"slack_redirect_uri,omitempty"`

	// Feature flags — global kill switches. False/absent means "defer to
	// the code's normal behavior" for flags that default to enabled;
	// these exist so an admin can turn OFF a misbehaving feature for
	// every tenant at once (e.g. a buggy AI insights prompt, or a
	// provider outage) without a deploy.
	AIInsightsEnabled     *bool `dynamodbav:"ai_insights_enabled,omitempty"`
	WhatsAppIngestEnabled *bool `dynamodbav:"whatsapp_ingest_enabled,omitempty"`
	EmailIngestEnabled    *bool `dynamodbav:"email_ingest_enabled,omitempty"`
	RazorpayIntegrationOn *bool `dynamodbav:"razorpay_integration_enabled,omitempty"`
	StripeIntegrationOn   *bool `dynamodbav:"stripe_integration_enabled,omitempty"`
	SlackIntegrationOn    *bool `dynamodbav:"slack_integration_enabled,omitempty"`
	NewSignupsEnabled     *bool `dynamodbav:"new_signups_enabled,omitempty"`

	UpdatedAt string `dynamodbav:"updated_at,omitempty"`
	UpdatedBy string `dynamodbav:"updated_by,omitempty"`
}

const (
	platformSettingsPK = "PLATFORM"
	platformSettingsSK = "SETTINGS"
)

type PlatformSettingsRepo struct{ client *dynamodb.Client }

func NewPlatformSettingsRepo() *PlatformSettingsRepo {
	return &PlatformSettingsRepo{client: db.Client()}
}

func (r *PlatformSettingsRepo) Get(ctx context.Context) (*PlatformSettingsItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: platformSettingsPK},
			"sk": &types.AttributeValueMemberS{Value: platformSettingsSK},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return &PlatformSettingsItem{PK: platformSettingsPK, SK: platformSettingsSK}, nil
	}
	var item PlatformSettingsItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

// Update performs a read-modify-write via the supplied mutate function —
// simplest correct approach for a single, rarely-written, admin-edited
// settings object (no concurrent-write contention concern the way a
// per-request entity like Document has).
func (r *PlatformSettingsRepo) Update(ctx context.Context, updatedBy string, mutate func(*PlatformSettingsItem)) (*PlatformSettingsItem, error) {
	current, err := r.Get(ctx)
	if err != nil {
		return nil, err
	}
	mutate(current)
	current.PK = platformSettingsPK
	current.SK = platformSettingsSK
	current.UpdatedAt = nowISO()
	current.UpdatedBy = updatedBy

	av, err := attributevalue.MarshalMap(current)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()), Item: av,
	}); err != nil {
		return nil, err
	}
	return current, nil
}
