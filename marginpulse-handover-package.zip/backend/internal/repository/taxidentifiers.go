package repository

import (
	"context"
	"errors"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

var ErrDuplicateTaxIdentifier = errors.New("this tax identifier is already registered on this account")

type TaxIdentifiersRepo struct{ client *dynamodb.Client }

func NewTaxIdentifiersRepo() *TaxIdentifiersRepo { return &TaxIdentifiersRepo{client: db.Client()} }

func guardSK(idType, idValue string) string { return db.TaxIdentifierGuardSK(idType, idValue) }

func (r *TaxIdentifiersRepo) GetByID(ctx context.Context, tenantID, taxIdentifierID string) (*TaxIdentifierItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.TaxIdentifierSK(taxIdentifierID)},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, ErrNotFound
	}
	var item TaxIdentifierItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TaxIdentifiersRepo) ListByTenant(ctx context.Context, tenantID string) ([]TaxIdentifierItem, error) {
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "TAXID#"},
		},
	})
	if err != nil {
		return nil, err
	}
	items := make([]TaxIdentifierItem, 0, len(out.Items))
	for _, raw := range out.Items {
		var t TaxIdentifierItem
		if err := attributevalue.UnmarshalMap(raw, &t); err != nil {
			return nil, err
		}
		items = append(items, t)
	}
	sortByCreatedAtDesc(items, func(t TaxIdentifierItem) string { return t.CreatedAt })
	return items, nil
}

type CreateTaxIdentifierInput struct {
	TenantID string
	IDType   string
	IDValue  string
	Label    string
}

// Create writes the tax identifier AND its uniqueness guard item in a
// single TransactWriteItems call — see tax_identifiers.py's identical
// pattern and rationale (this is the one entity where a real atomic
// guard was judged worth the complexity, since duplicate submissions
// would trigger duplicate paid external verification calls).
func (r *TaxIdentifiersRepo) Create(ctx context.Context, in CreateTaxIdentifierInput) (*TaxIdentifierItem, error) {
	taxIdentifierID := uuid.NewString()
	now := nowISO()
	pk := db.TenantPK(in.TenantID)

	item := TaxIdentifierItem{
		PK:                 pk,
		SK:                 db.TaxIdentifierSK(taxIdentifierID),
		TaxIdentifierID:    taxIdentifierID,
		TenantID:           in.TenantID,
		IDType:             in.IDType,
		IDValue:            in.IDValue,
		Label:              in.Label,
		VerificationStatus: "PENDING",
		IsPrimary:          false,
		CreatedAt:          now,
		UpdatedAt:          now,
	}
	guard := TaxIdentifierGuardItem{
		PK:              pk,
		SK:              guardSK(in.IDType, in.IDValue),
		TaxIdentifierID: taxIdentifierID,
	}

	itemAV, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	guardAV, err := attributevalue.MarshalMap(guard)
	if err != nil {
		return nil, err
	}

	_, err = r.client.TransactWriteItems(ctx, &dynamodb.TransactWriteItemsInput{
		TransactItems: []types.TransactWriteItem{
			{
				Put: &types.Put{
					TableName:           aws.String(db.TableName()),
					Item:                guardAV,
					ConditionExpression: aws.String("attribute_not_exists(pk)"),
				},
			},
			{
				Put: &types.Put{
					TableName: aws.String(db.TableName()),
					Item:      itemAV,
				},
			},
		},
	})
	if err != nil {
		var cancelled *types.TransactionCanceledException
		if errors.As(err, &cancelled) {
			return nil, ErrDuplicateTaxIdentifier
		}
		return nil, err
	}
	return &item, nil
}

func (r *TaxIdentifiersRepo) UpdateFields(ctx context.Context, tenantID, taxIdentifierID string, updates []FieldUpdate) (*TaxIdentifierItem, error) {
	setParts := []string{}
	removeParts := []string{}
	names := map[string]string{}
	values := map[string]types.AttributeValue{}

	for _, u := range updates {
		namePh := "#" + u.Name
		names[namePh] = u.Name
		if u.Value == nil {
			removeParts = append(removeParts, namePh)
			continue
		}
		av, err := attributevalue.Marshal(u.Value)
		if err != nil {
			return nil, err
		}
		valPh := ":" + u.Name
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
	}
	names["#updated_at"] = "updated_at"
	values[":updated_at"] = &types.AttributeValueMemberS{Value: nowISO()}
	setParts = append(setParts, "#updated_at = :updated_at")

	expr := "SET " + strings.Join(setParts, ", ")
	if len(removeParts) > 0 {
		expr += " REMOVE " + strings.Join(removeParts, ", ")
	}

	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.TaxIdentifierSK(taxIdentifierID)},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item TaxIdentifierItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

// Delete removes the tax identifier AND its uniqueness guard together,
// freeing the (id_type, id_value) combination for future reuse.
func (r *TaxIdentifiersRepo) Delete(ctx context.Context, tenantID, taxIdentifierID string) error {
	existing, err := r.GetByID(ctx, tenantID, taxIdentifierID)
	if err != nil {
		if errors.Is(err, ErrNotFound) {
			return nil
		}
		return err
	}
	pk := db.TenantPK(tenantID)
	_, err = r.client.TransactWriteItems(ctx, &dynamodb.TransactWriteItemsInput{
		TransactItems: []types.TransactWriteItem{
			{Delete: &types.Delete{
				TableName: aws.String(db.TableName()),
				Key: map[string]types.AttributeValue{
					"pk": &types.AttributeValueMemberS{Value: pk},
					"sk": &types.AttributeValueMemberS{Value: db.TaxIdentifierSK(taxIdentifierID)},
				},
			}},
			{Delete: &types.Delete{
				TableName: aws.String(db.TableName()),
				Key: map[string]types.AttributeValue{
					"pk": &types.AttributeValueMemberS{Value: pk},
					"sk": &types.AttributeValueMemberS{Value: guardSK(existing.IDType, existing.IDValue)},
				},
			}},
		},
	})
	return err
}

func (r *TaxIdentifiersRepo) ClearPrimaryForType(ctx context.Context, tenantID, idType, exceptID string) error {
	all, err := r.ListByTenant(ctx, tenantID)
	if err != nil {
		return err
	}
	for _, t := range all {
		if t.IDType == idType && t.IsPrimary && t.TaxIdentifierID != exceptID {
			if _, err := r.UpdateFields(ctx, tenantID, t.TaxIdentifierID, []FieldUpdate{F("is_primary", false)}); err != nil {
				return err
			}
		}
	}
	return nil
}
