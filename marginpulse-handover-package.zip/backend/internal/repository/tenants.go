package repository

import (
	"context"
	"errors"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

var ErrNotFound = errors.New("item not found")

type TenantsRepo struct{ client *dynamodb.Client }

func NewTenantsRepo() *TenantsRepo { return &TenantsRepo{client: db.Client()} }

// ListAll returns every tenant in the system — for the platform admin
// panel's tenant overview ONLY. Uses a Scan (not a Query), which is the
// one deliberate exception to this codebase's "no Scan" discipline
// elsewhere: there is no GSI for "every tenant across the whole table"
// because nothing in the normal product flow ever needs one, and adding
// a 4th GSI just for this admin-only, low-frequency screen would cost
// more provisioned capacity (see DYNAMODB_SCHEMA.md's free-tier budget)
// than an occasional Scan does. Not suitable for a hot path — it reads
// every item in the table and filters client-side.
func (r *TenantsRepo) ListAll(ctx context.Context, limit int32) ([]SimpleTenant, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	var out []SimpleTenant
	var startKey map[string]types.AttributeValue

	for {
		input := &dynamodb.ScanInput{
			TableName:        aws.String(db.TableName()),
			FilterExpression: aws.String("sk = :sk"),
			ExpressionAttributeValues: map[string]types.AttributeValue{
				":sk": &types.AttributeValueMemberS{Value: db.TenantSK},
			},
		}
		if startKey != nil {
			input.ExclusiveStartKey = startKey
		}
		resp, err := r.client.Scan(ctx, input)
		if err != nil {
			return nil, err
		}
		for _, raw := range resp.Items {
			var t TenantItem
			if err := attributevalue.UnmarshalMap(raw, &t); err != nil {
				continue
			}
			out = append(out, SimpleTenant{
				TenantID: t.TenantID, BusinessName: t.BusinessName, OwnerEmail: t.OwnerEmail,
				PlanTier: t.PlanTier, IsActive: t.IsActive, IsPlatformAdmin: t.IsPlatformAdmin,
				CreatedAt: t.CreatedAt,
			})
			if int32(len(out)) >= limit {
				return out, nil
			}
		}
		if len(resp.LastEvaluatedKey) == 0 {
			break
		}
		startKey = resp.LastEvaluatedKey
	}
	return out, nil
}

// SimpleTenant is the trimmed shape returned by ListAll — deliberately
// excludes hashed_password and other sensitive fields the admin panel
// has no legitimate need to receive over the wire at all.
type SimpleTenant struct {
	TenantID        string
	BusinessName    string
	OwnerEmail      string
	PlanTier        string
	IsActive        bool
	IsPlatformAdmin bool
	CreatedAt       string
}

func (r *TenantsRepo) GetByID(ctx context.Context, tenantID string) (*TenantItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.TenantSK},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, ErrNotFound
	}
	var item TenantItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TenantsRepo) GetByEmail(ctx context.Context, email string) (*TenantItem, error) {
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI1"),
		KeyConditionExpression: aws.String("gsi1pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.TenantGSI1PKEmail(email)},
		},
		Limit: aws.Int32(1),
	})
	if err != nil {
		return nil, err
	}
	if len(out.Items) == 0 {
		return nil, ErrNotFound
	}
	var item TenantItem
	if err := attributevalue.UnmarshalMap(out.Items[0], &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TenantsRepo) GetByWhatsAppPhone(ctx context.Context, phone string) (*TenantItem, error) {
	if phone == "" {
		return nil, ErrNotFound
	}
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI2"),
		KeyConditionExpression: aws.String("gsi2pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.TenantGSI2PKWhatsApp(phone)},
		},
		Limit: aws.Int32(1),
	})
	if err != nil {
		return nil, err
	}
	if len(out.Items) == 0 {
		return nil, ErrNotFound
	}
	var item TenantItem
	if err := attributevalue.UnmarshalMap(out.Items[0], &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *TenantsRepo) GetByIngestEmailAlias(ctx context.Context, alias string) (*TenantItem, error) {
	if alias == "" {
		return nil, ErrNotFound
	}
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI3"),
		KeyConditionExpression: aws.String("gsi3pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.TenantGSI3PKIngestEmail(alias)},
		},
		Limit: aws.Int32(1),
	})
	if err != nil {
		return nil, err
	}
	if len(out.Items) == 0 {
		return nil, ErrNotFound
	}
	var item TenantItem
	if err := attributevalue.UnmarshalMap(out.Items[0], &item); err != nil {
		return nil, err
	}
	return &item, nil
}

type CreateTenantInput struct {
	BusinessName         string
	OwnerEmail           string
	HashedPassword       string
	CountryCode          string
	WhatsAppBindingPhone string
}

// Create inserts a new tenant. Uniqueness on owner_email is checked via
// GetByEmail() BEFORE calling this (in the auth handler), not via a
// DynamoDB transaction — see tenants.py's identical tradeoff note for
// why this is an accepted gap at this app's traffic level.
func (r *TenantsRepo) Create(ctx context.Context, in CreateTenantInput) (*TenantItem, error) {
	tenantID := uuid.NewString()
	now := nowISO()
	item := TenantItem{
		PK:                   db.TenantPK(tenantID),
		SK:                   db.TenantSK,
		GSI1PK:               db.TenantGSI1PKEmail(in.OwnerEmail),
		GSI1SK:               "TENANT#" + tenantID,
		TenantID:             tenantID,
		BusinessName:         in.BusinessName,
		OwnerEmail:           in.OwnerEmail,
		HashedPassword:       in.HashedPassword,
		CountryCode:          in.CountryCode,
		WhatsAppBindingPhone: in.WhatsAppBindingPhone,
		GSTRegistered:        false,
		PlanTier:             "FREE",
		IsActive:             true,
		CreatedAt:            now,
		UpdatedAt:            now,
	}
	if in.WhatsAppBindingPhone != "" {
		item.GSI2PK = db.TenantGSI2PKWhatsApp(in.WhatsAppBindingPhone)
		item.GSI2SK = "TENANT#" + tenantID
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	_, err = r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	})
	if err != nil {
		return nil, err
	}
	return &item, nil
}

// UpdateFields applies a partial update via read-modify-write (PutItem
// of the full item) rather than a field-level UpdateExpression — simpler
// given struct-tag marshaling, at the cost of last-write-wins semantics
// under concurrent updates to the same tenant. Acceptable here since
// tenant profile/settings edits are low-concurrency, single-admin
// operations; switch to UpdateExpression (see documents.go's
// UpdateFields for that pattern) if concurrent-edit safety ever matters
// for this entity.
func (r *TenantsRepo) UpdateFields(ctx context.Context, tenantID string, mutate func(*TenantItem)) (*TenantItem, error) {
	current, err := r.GetByID(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	mutate(current)
	current.UpdatedAt = nowISO()
	current.GSI1PK = db.TenantGSI1PKEmail(current.OwnerEmail)
	current.GSI1SK = "TENANT#" + tenantID
	if current.WhatsAppBindingPhone != "" {
		current.GSI2PK = db.TenantGSI2PKWhatsApp(current.WhatsAppBindingPhone)
		current.GSI2SK = "TENANT#" + tenantID
	} else {
		current.GSI2PK = ""
		current.GSI2SK = ""
	}
	if current.IngestEmailAlias != "" {
		current.GSI3PK = db.TenantGSI3PKIngestEmail(current.IngestEmailAlias)
		current.GSI3SK = "TENANT#" + tenantID
	} else {
		current.GSI3PK = ""
		current.GSI3SK = ""
	}

	av, err := attributevalue.MarshalMap(current)
	if err != nil {
		return nil, err
	}
	_, err = r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	})
	if err != nil {
		return nil, err
	}
	return current, nil
}
