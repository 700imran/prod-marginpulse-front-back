package repository

import (
	"context"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

type BankTransactionsRepo struct{ client *dynamodb.Client }

func NewBankTransactionsRepo() *BankTransactionsRepo {
	return &BankTransactionsRepo{client: db.Client()}
}

type CreateBankTransactionInput struct {
	TenantID        string
	Narration       string
	TransactionDate string // ISO date "2026-07-02"
	DebitAmount     float64
	CreditAmount    float64
	BankReference   string
	BankName        string
	SourceFilename  string
}

func (r *BankTransactionsRepo) Create(ctx context.Context, in CreateBankTransactionInput) (*BankTransactionItem, error) {
	transactionID := uuid.NewString()
	now := nowISO()
	item := BankTransactionItem{
		PK:                   db.TenantPK(in.TenantID),
		SK:                   db.BankTxnSK(in.TransactionDate, transactionID),
		GSI2PK:               db.BankTxnGSI2PKUnmatched(in.TenantID),
		GSI2SK:               db.BankTxnSK(in.TransactionDate, transactionID),
		TransactionID:        transactionID,
		TenantID:             in.TenantID,
		BankReference:        in.BankReference,
		Narration:            in.Narration,
		TransactionDate:      in.TransactionDate,
		DebitAmount:          in.DebitAmount,
		CreditAmount:         in.CreditAmount,
		Currency:             "INR",
		ReconciliationStatus: "UNMATCHED",
		BankName:             in.BankName,
		SourceFilename:       in.SourceFilename,
		CreatedAt:            now,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

// UpdateFields requires transactionDate since it's embedded in the sort
// key — same requirement as the Python version. If reconciliation_status
// moves away from UNMATCHED, GSI2's sparse attributes are removed.
func (r *BankTransactionsRepo) UpdateFields(ctx context.Context, tenantID, transactionID, transactionDate string, updates []FieldUpdate) (*BankTransactionItem, error) {
	setParts := []string{}
	removeParts := []string{}
	names := map[string]string{}
	values := map[string]types.AttributeValue{}
	var newStatus string

	for _, u := range updates {
		namePh := "#" + u.Name
		names[namePh] = u.Name
		if u.Value == nil {
			removeParts = append(removeParts, namePh)
			continue
		}
		av, err := attributevalue.Marshal(u.Value)
		if err != nil {
			return nil, err
		}
		valPh := ":" + u.Name
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
		if u.Name == "reconciliation_status" {
			if s, ok := u.Value.(string); ok {
				newStatus = s
			}
		}
	}

	if newStatus != "" && newStatus != "UNMATCHED" {
		names["#gsi2pk"] = "gsi2pk"
		names["#gsi2sk"] = "gsi2sk"
		removeParts = append(removeParts, "#gsi2pk", "#gsi2sk")
	}

	expr := ""
	if len(setParts) > 0 {
		expr += "SET " + strings.Join(setParts, ", ")
	}
	if len(removeParts) > 0 {
		if expr != "" {
			expr += " "
		}
		expr += "REMOVE " + strings.Join(removeParts, ", ")
	}

	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.BankTxnSK(transactionDate, transactionID)},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item BankTransactionItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

// ListUnmatchedInDateRange is an efficient sorted range Query against
// the sparse GSI2 UNMATCHED index — used by the reconciliation pipeline
// to find candidate bank transactions within N days of an invoice date.
func (r *BankTransactionsRepo) ListUnmatchedInDateRange(ctx context.Context, tenantID, startDateISO, endDateISO string) ([]BankTransactionItem, error) {
	pk := db.BankTxnGSI2PKUnmatched(tenantID)
	skStart := db.BankTxnSK(startDateISO, "")
	skEnd := db.BankTxnSK(endDateISO, "\uffff")

	var items []BankTransactionItem
	paginator := dynamodb.NewQueryPaginator(r.client, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI2"),
		KeyConditionExpression: aws.String("gsi2pk = :pk AND gsi2sk BETWEEN :start AND :end"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":    &types.AttributeValueMemberS{Value: pk},
			":start": &types.AttributeValueMemberS{Value: skStart},
			":end":   &types.AttributeValueMemberS{Value: skEnd},
		},
	})
	for paginator.HasMorePages() {
		page, err := paginator.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, raw := range page.Items {
			var item BankTransactionItem
			if err := attributevalue.UnmarshalMap(raw, &item); err != nil {
				return nil, err
			}
			items = append(items, item)
		}
	}
	return items, nil
}
