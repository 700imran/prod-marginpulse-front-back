package repository

import (
	"context"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"

	"github.com/marginpulse/backend/internal/db"
)

// IntegrationItem is the DynamoDB item shape for TENANT#<id> / INTEGRATION#<provider>.
// One item per connected third-party service — covers BOTH OAuth-based
// providers (Google, Apple, Slack — access_token/refresh_token) and
// API-key-based providers (Razorpay, Stripe — api_key/api_secret), since
// a single tenant-scoped "which external services are connected, and
// with what credentials" record is the same shape either way; only
// which fields are populated differs per provider.
type IntegrationItem struct {
	PK string `dynamodbav:"pk"`
	SK string `dynamodbav:"sk"`

	TenantID              string `dynamodbav:"tenant_id"`
	Provider              string `dynamodbav:"provider"` // GOOGLE | APPLE | SLACK | RAZORPAY | STRIPE | PAYPAL | SQUARE | NOTION | QUICKBOOKS | XERO | TALLY | HUBSPOT | SALESFORCE
	Status                string `dynamodbav:"status"`   // CONNECTED | DISCONNECTED | ERROR
	AccessTokenEncrypted  string `dynamodbav:"access_token_encrypted,omitempty"`
	RefreshTokenEncrypted string `dynamodbav:"refresh_token_encrypted,omitempty"`
	APIKeyEncrypted       string `dynamodbav:"api_key_encrypted,omitempty"`
	APISecretEncrypted    string `dynamodbav:"api_secret_encrypted,omitempty"`
	TokenExpiresAt        string `dynamodbav:"token_expires_at,omitempty"`
	ExternalAccountID     string `dynamodbav:"external_account_id,omitempty"`
	ExternalAccountName   string `dynamodbav:"external_account_name,omitempty"`
	Scopes                string `dynamodbav:"scopes,omitempty"`
	LastError             string `dynamodbav:"last_error,omitempty"`
	ConnectedAt           string `dynamodbav:"connected_at"`
	LastSyncedAt          string `dynamodbav:"last_synced_at,omitempty"`
	UpdatedAt             string `dynamodbav:"updated_at"`
}

func integrationSK(provider string) string {
	return "INTEGRATION#" + strings.ToUpper(provider)
}

type IntegrationsRepo struct{ client *dynamodb.Client }

func NewIntegrationsRepo() *IntegrationsRepo { return &IntegrationsRepo{client: db.Client()} }

func (r *IntegrationsRepo) GetByProvider(ctx context.Context, tenantID, provider string) (*IntegrationItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: integrationSK(provider)},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, ErrNotFound
	}
	var item IntegrationItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *IntegrationsRepo) ListByTenant(ctx context.Context, tenantID string) ([]IntegrationItem, error) {
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "INTEGRATION#"},
		},
	})
	if err != nil {
		return nil, err
	}
	items := make([]IntegrationItem, 0, len(out.Items))
	for _, raw := range out.Items {
		var it IntegrationItem
		if err := attributevalue.UnmarshalMap(raw, &it); err != nil {
			return nil, err
		}
		items = append(items, it)
	}
	return items, nil
}

// Upsert creates or fully replaces the integration record for a
// provider — connect/reconnect always writes a complete new item rather
// than a partial UpdateExpression, since credentials rotate as a whole
// unit (a new OAuth token pair, or a new API key pair) rather than
// field-by-field.
func (r *IntegrationsRepo) Upsert(ctx context.Context, item IntegrationItem) (*IntegrationItem, error) {
	item.PK = db.TenantPK(item.TenantID)
	item.SK = integrationSK(item.Provider)
	item.Provider = strings.ToUpper(item.Provider)
	item.UpdatedAt = nowISO()
	if item.ConnectedAt == "" {
		item.ConnectedAt = item.UpdatedAt
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()), Item: av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *IntegrationsRepo) UpdateFields(ctx context.Context, tenantID, provider string, updates []FieldUpdate) (*IntegrationItem, error) {
	setParts := []string{}
	removeParts := []string{}
	names := map[string]string{}
	values := map[string]types.AttributeValue{}

	for _, u := range updates {
		namePh := "#" + u.Name
		names[namePh] = u.Name
		if u.Value == nil {
			removeParts = append(removeParts, namePh)
			continue
		}
		av, err := attributevalue.Marshal(u.Value)
		if err != nil {
			return nil, err
		}
		valPh := ":" + u.Name
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
	}
	names["#updated_at"] = "updated_at"
	values[":updated_at"] = &types.AttributeValueMemberS{Value: nowISO()}
	setParts = append(setParts, "#updated_at = :updated_at")

	expr := "SET " + strings.Join(setParts, ", ")
	if len(removeParts) > 0 {
		expr += " REMOVE " + strings.Join(removeParts, ", ")
	}

	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: integrationSK(provider)},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item IntegrationItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *IntegrationsRepo) Disconnect(ctx context.Context, tenantID, provider string) error {
	_, err := r.client.DeleteItem(ctx, &dynamodb.DeleteItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: integrationSK(provider)},
		},
	})
	return err
}
