package repository

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"

	"github.com/marginpulse/backend/internal/db"
)

// ReconciliationSettingsItem — one item per tenant, lazily created with
// defaults on first GET (mirrors settings.py's _get_or_create helper).
type ReconciliationSettingsItem struct {
	PK                     string `dynamodbav:"pk"`
	SK                     string `dynamodbav:"sk"`
	TenantID               string `dynamodbav:"tenant_id"`
	FuzzyVendorMatching    bool   `dynamodbav:"fuzzy_vendor_matching"`
	DateDriftTolerance     bool   `dynamodbav:"date_drift_tolerance"`
	OCRConfidenceThreshold int    `dynamodbav:"ocr_confidence_threshold"`
}

type NotificationSettingsItem struct {
	PK                      string  `dynamodbav:"pk"`
	SK                      string  `dynamodbav:"sk"`
	TenantID                string  `dynamodbav:"tenant_id"`
	CriticalITCMissingAlert bool    `dynamodbav:"critical_itc_missing_alert"`
	CriticalITCThresholdINR float64 `dynamodbav:"critical_itc_threshold_inr"`
	WeeklyAuditSummary      bool    `dynamodbav:"weekly_audit_summary"`
}

type IntegrationSettingsItem struct {
	PK                      string `dynamodbav:"pk"`
	SK                      string `dynamodbav:"sk"`
	TenantID                string `dynamodbav:"tenant_id"`
	GSTAutoSyncEnabled      bool   `dynamodbav:"gst_auto_sync_enabled"`
	GSTAutoSyncDayOfMonth   int    `dynamodbav:"gst_auto_sync_day_of_month"`
	WhatsAppOutboundEnabled bool   `dynamodbav:"whatsapp_outbound_enabled"`
}

type SettingsRepo struct{ client *dynamodb.Client }

func NewSettingsRepo() *SettingsRepo { return &SettingsRepo{client: db.Client()} }

func (r *SettingsRepo) GetOrCreateReconciliation(ctx context.Context, tenantID string) (*ReconciliationSettingsItem, error) {
	key := map[string]types.AttributeValue{
		"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
		"sk": &types.AttributeValueMemberS{Value: db.SettingsSKReconciliation},
	}
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{TableName: aws.String(db.TableName()), Key: key})
	if err != nil {
		return nil, err
	}
	if out.Item != nil {
		var item ReconciliationSettingsItem
		if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
			return nil, err
		}
		return &item, nil
	}
	// Defaults mirror the SQLAlchemy model's column defaults.
	item := ReconciliationSettingsItem{
		PK: db.TenantPK(tenantID), SK: db.SettingsSKReconciliation, TenantID: tenantID,
		FuzzyVendorMatching: true, DateDriftTolerance: true, OCRConfidenceThreshold: 70,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(db.TableName()), Item: av}); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *SettingsRepo) UpdateReconciliation(ctx context.Context, tenantID string, updates []FieldUpdate) (*ReconciliationSettingsItem, error) {
	if _, err := r.GetOrCreateReconciliation(ctx, tenantID); err != nil {
		return nil, err
	}
	out, err := updateSettingsFields(ctx, r.client, db.TenantPK(tenantID), db.SettingsSKReconciliation, updates)
	if err != nil {
		return nil, err
	}
	var item ReconciliationSettingsItem
	if err := attributevalue.UnmarshalMap(out, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *SettingsRepo) GetOrCreateNotifications(ctx context.Context, tenantID string) (*NotificationSettingsItem, error) {
	key := map[string]types.AttributeValue{
		"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
		"sk": &types.AttributeValueMemberS{Value: db.SettingsSKNotifications},
	}
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{TableName: aws.String(db.TableName()), Key: key})
	if err != nil {
		return nil, err
	}
	if out.Item != nil {
		var item NotificationSettingsItem
		if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
			return nil, err
		}
		return &item, nil
	}
	item := NotificationSettingsItem{
		PK: db.TenantPK(tenantID), SK: db.SettingsSKNotifications, TenantID: tenantID,
		CriticalITCMissingAlert: true, CriticalITCThresholdINR: 50000, WeeklyAuditSummary: true,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(db.TableName()), Item: av}); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *SettingsRepo) UpdateNotifications(ctx context.Context, tenantID string, updates []FieldUpdate) (*NotificationSettingsItem, error) {
	if _, err := r.GetOrCreateNotifications(ctx, tenantID); err != nil {
		return nil, err
	}
	out, err := updateSettingsFields(ctx, r.client, db.TenantPK(tenantID), db.SettingsSKNotifications, updates)
	if err != nil {
		return nil, err
	}
	var item NotificationSettingsItem
	if err := attributevalue.UnmarshalMap(out, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *SettingsRepo) GetOrCreateIntegrations(ctx context.Context, tenantID string) (*IntegrationSettingsItem, error) {
	key := map[string]types.AttributeValue{
		"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
		"sk": &types.AttributeValueMemberS{Value: db.SettingsSKIntegrations},
	}
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{TableName: aws.String(db.TableName()), Key: key})
	if err != nil {
		return nil, err
	}
	if out.Item != nil {
		var item IntegrationSettingsItem
		if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
			return nil, err
		}
		return &item, nil
	}
	item := IntegrationSettingsItem{
		PK: db.TenantPK(tenantID), SK: db.SettingsSKIntegrations, TenantID: tenantID,
		GSTAutoSyncEnabled: false, GSTAutoSyncDayOfMonth: 11, WhatsAppOutboundEnabled: false,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{TableName: aws.String(db.TableName()), Item: av}); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *SettingsRepo) UpdateIntegrations(ctx context.Context, tenantID string, updates []FieldUpdate) (*IntegrationSettingsItem, error) {
	if _, err := r.GetOrCreateIntegrations(ctx, tenantID); err != nil {
		return nil, err
	}
	out, err := updateSettingsFields(ctx, r.client, db.TenantPK(tenantID), db.SettingsSKIntegrations, updates)
	if err != nil {
		return nil, err
	}
	var item IntegrationSettingsItem
	if err := attributevalue.UnmarshalMap(out, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func updateSettingsFields(ctx context.Context, client *dynamodb.Client, pk, sk string, updates []FieldUpdate) (map[string]types.AttributeValue, error) {
	if len(updates) == 0 {
		out, err := client.GetItem(ctx, &dynamodb.GetItemInput{
			TableName: aws.String(db.TableName()),
			Key: map[string]types.AttributeValue{
				"pk": &types.AttributeValueMemberS{Value: pk},
				"sk": &types.AttributeValueMemberS{Value: sk},
			},
		})
		if err != nil {
			return nil, err
		}
		return out.Item, nil
	}

	setParts := make([]string, 0, len(updates))
	names := map[string]string{}
	values := map[string]types.AttributeValue{}
	for _, u := range updates {
		namePh := "#" + u.Name
		valPh := ":" + u.Name
		names[namePh] = u.Name
		av, err := attributevalue.Marshal(u.Value)
		if err != nil {
			return nil, err
		}
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
	}
	expr := "SET "
	for i, p := range setParts {
		if i > 0 {
			expr += ", "
		}
		expr += p
	}

	out, err := client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: pk},
			"sk": &types.AttributeValueMemberS{Value: sk},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	return out.Attributes, nil
}
