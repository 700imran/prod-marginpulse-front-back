package repository

import (
	"context"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

// AnomaliesRepo — NOTE (carried over unchanged from the Python version):
// nothing in this codebase actually calls Create() anywhere; the
// endpoints only read and resolve existing anomalies. See anomalies.py's
// identical note for why this is a pre-existing gap, not one introduced
// by this port.
type AnomaliesRepo struct{ client *dynamodb.Client }

func NewAnomaliesRepo() *AnomaliesRepo { return &AnomaliesRepo{client: db.Client()} }

type CreateAnomalyInput struct {
	TenantID             string
	DocumentID           string
	RelatedTransactionID string
	AnomalyType          string
	Severity             string
	Description          string
	SuggestedAction      string
}

func (r *AnomaliesRepo) Create(ctx context.Context, in CreateAnomalyInput) (*AnomalyItem, error) {
	anomalyID := uuid.NewString()
	now := nowISO()
	item := AnomalyItem{
		PK:                   db.TenantPK(in.TenantID),
		SK:                   db.AnomalySK(now, anomalyID),
		AnomalyID:            anomalyID,
		TenantID:             in.TenantID,
		DocumentID:           in.DocumentID,
		RelatedTransactionID: in.RelatedTransactionID,
		AnomalyType:          in.AnomalyType,
		Severity:             in.Severity,
		Description:          in.Description,
		SuggestedAction:      in.SuggestedAction,
		Status:               "OPEN",
		CreatedAt:            now,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

type ListAnomaliesOptions struct {
	Status   string
	Severity string
	Limit    int32
}

func (r *AnomaliesRepo) ListByTenant(ctx context.Context, tenantID string, opts ListAnomaliesOptions) ([]AnomalyItem, error) {
	input := &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "ANOMALY#"},
		},
		ScanIndexForward: aws.Bool(false),
	}
	var filters []string
	names := map[string]string{}
	if opts.Status != "" {
		filters = append(filters, "#status = :status")
		names["#status"] = "status"
		input.ExpressionAttributeValues[":status"] = &types.AttributeValueMemberS{Value: strings.ToUpper(opts.Status)}
	}
	if opts.Severity != "" {
		filters = append(filters, "severity = :severity")
		input.ExpressionAttributeValues[":severity"] = &types.AttributeValueMemberS{Value: strings.ToUpper(opts.Severity)}
	}
	if len(filters) > 0 {
		input.FilterExpression = aws.String(strings.Join(filters, " AND "))
		input.ExpressionAttributeNames = names
	}
	if opts.Limit > 0 {
		input.Limit = aws.Int32(opts.Limit)
	}

	out, err := r.client.Query(ctx, input)
	if err != nil {
		return nil, err
	}
	items := make([]AnomalyItem, 0, len(out.Items))
	for _, raw := range out.Items {
		var a AnomalyItem
		if err := attributevalue.UnmarshalMap(raw, &a); err != nil {
			return nil, err
		}
		items = append(items, a)
	}
	return items, nil
}

// GetByID does a bounded per-tenant scan-and-match since anomaly_id
// alone can't build the sort key (it embeds created_at) — same
// tradeoff as anomalies.py's get_by_id, fine at expected anomaly volume.
func (r *AnomaliesRepo) GetByID(ctx context.Context, tenantID, anomalyID string) (*AnomalyItem, error) {
	all, err := r.ListByTenant(ctx, tenantID, ListAnomaliesOptions{})
	if err != nil {
		return nil, err
	}
	for _, a := range all {
		if a.AnomalyID == anomalyID {
			return &a, nil
		}
	}
	return nil, ErrNotFound
}

// ExistsOpenForRelatedTransaction checks whether an OPEN anomaly has
// already been raised against this bank transaction — used by
// missing-invoice detection so re-running the scan doesn't create a
// fresh duplicate anomaly every time for the same still-unresolved gap.
func (r *AnomaliesRepo) ExistsOpenForRelatedTransaction(ctx context.Context, tenantID, transactionID string) (bool, error) {
	all, err := r.ListByTenant(ctx, tenantID, ListAnomaliesOptions{Status: "OPEN"})
	if err != nil {
		return false, err
	}
	for _, a := range all {
		if a.RelatedTransactionID == transactionID {
			return true, nil
		}
	}
	return false, nil
}

func (r *AnomaliesRepo) Resolve(ctx context.Context, tenantID, anomalyID, createdAtISO, resolvedBy string) (*AnomalyItem, error) {
	values := map[string]types.AttributeValue{
		":status":      &types.AttributeValueMemberS{Value: "RESOLVED"},
		":resolved_at": &types.AttributeValueMemberS{Value: nowISO()},
	}
	updateExpr := "SET #status = :status, resolved_at = :resolved_at"
	if resolvedBy != "" {
		values[":resolved_by"] = &types.AttributeValueMemberS{Value: resolvedBy}
		updateExpr += ", resolved_by = :resolved_by"
	}
	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.AnomalySK(createdAtISO, anomalyID)},
		},
		UpdateExpression:          aws.String(updateExpr),
		ExpressionAttributeNames:  map[string]string{"#status": "status"},
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item AnomalyItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}
