package repository

import (
	"context"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

type BankAccountsRepo struct{ client *dynamodb.Client }

func NewBankAccountsRepo() *BankAccountsRepo { return &BankAccountsRepo{client: db.Client()} }

func (r *BankAccountsRepo) GetByID(ctx context.Context, tenantID, bankAccountID string) (*BankAccountItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.BankAccountSK(bankAccountID)},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, ErrNotFound
	}
	var item BankAccountItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *BankAccountsRepo) ListByTenant(ctx context.Context, tenantID string) ([]BankAccountItem, error) {
	out, err := r.client.Query(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "BANKACCT#"},
		},
	})
	if err != nil {
		return nil, err
	}
	items := make([]BankAccountItem, 0, len(out.Items))
	for _, raw := range out.Items {
		var b BankAccountItem
		if err := attributevalue.UnmarshalMap(raw, &b); err != nil {
			return nil, err
		}
		items = append(items, b)
	}
	sortByCreatedAtDesc(items, func(b BankAccountItem) string { return b.CreatedAt })
	return items, nil
}

func (r *BankAccountsRepo) FindByLast4AndIFSC(ctx context.Context, tenantID, last4, ifsc string) (*BankAccountItem, error) {
	all, err := r.ListByTenant(ctx, tenantID)
	if err != nil {
		return nil, err
	}
	for _, a := range all {
		if a.AccountNumberLast4 == last4 && a.IFSCCode == ifsc {
			return &a, nil
		}
	}
	return nil, ErrNotFound
}

type CreateBankAccountInput struct {
	TenantID               string
	BankName               string
	AccountHolderName      string
	AccountNumberEncrypted string
	AccountNumberLast4     string
	IFSCCode               string
	AccountType            string
}

func (r *BankAccountsRepo) Create(ctx context.Context, in CreateBankAccountInput) (*BankAccountItem, error) {
	bankAccountID := uuid.NewString()
	now := nowISO()
	accountType := in.AccountType
	if accountType == "" {
		accountType = "CURRENT"
	}
	item := BankAccountItem{
		PK:                     db.TenantPK(in.TenantID),
		SK:                     db.BankAccountSK(bankAccountID),
		BankAccountID:          bankAccountID,
		TenantID:               in.TenantID,
		BankName:               in.BankName,
		AccountHolderName:      in.AccountHolderName,
		AccountNumberEncrypted: in.AccountNumberEncrypted,
		AccountNumberLast4:     in.AccountNumberLast4,
		IFSCCode:               in.IFSCCode,
		AccountType:            accountType,
		VerificationStatus:     "PENDING",
		IsPrimary:              false,
		CreatedAt:              now,
		UpdatedAt:              now,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *BankAccountsRepo) UpdateFields(ctx context.Context, tenantID, bankAccountID string, updates []FieldUpdate) (*BankAccountItem, error) {
	setParts := []string{}
	removeParts := []string{}
	names := map[string]string{}
	values := map[string]types.AttributeValue{}

	for _, u := range updates {
		namePh := "#" + u.Name
		names[namePh] = u.Name
		if u.Value == nil {
			removeParts = append(removeParts, namePh)
			continue
		}
		av, err := attributevalue.Marshal(u.Value)
		if err != nil {
			return nil, err
		}
		valPh := ":" + u.Name
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
	}
	names["#updated_at"] = "updated_at"
	values[":updated_at"] = &types.AttributeValueMemberS{Value: nowISO()}
	setParts = append(setParts, "#updated_at = :updated_at")

	expr := "SET " + strings.Join(setParts, ", ")
	if len(removeParts) > 0 {
		expr += " REMOVE " + strings.Join(removeParts, ", ")
	}

	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.BankAccountSK(bankAccountID)},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item BankAccountItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *BankAccountsRepo) Delete(ctx context.Context, tenantID, bankAccountID string) error {
	_, err := r.client.DeleteItem(ctx, &dynamodb.DeleteItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.BankAccountSK(bankAccountID)},
		},
	})
	return err
}

func (r *BankAccountsRepo) ClearPrimary(ctx context.Context, tenantID, exceptID string) error {
	all, err := r.ListByTenant(ctx, tenantID)
	if err != nil {
		return err
	}
	for _, a := range all {
		if a.IsPrimary && a.BankAccountID != exceptID {
			if _, err := r.UpdateFields(ctx, tenantID, a.BankAccountID, []FieldUpdate{F("is_primary", false)}); err != nil {
				return err
			}
		}
	}
	return nil
}
