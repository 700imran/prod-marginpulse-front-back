package repository

import (
	"context"
	"sort"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

type DocumentsRepo struct{ client *dynamodb.Client }

func NewDocumentsRepo() *DocumentsRepo { return &DocumentsRepo{client: db.Client()} }

func (r *DocumentsRepo) GetByID(ctx context.Context, tenantID, documentID string) (*DocumentItem, error) {
	out, err := r.client.GetItem(ctx, &dynamodb.GetItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.DocumentSK(documentID)},
		},
	})
	if err != nil {
		return nil, err
	}
	if out.Item == nil {
		return nil, ErrNotFound
	}
	var item DocumentItem
	if err := attributevalue.UnmarshalMap(out.Item, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

type CreateDocumentInput struct {
	TenantID          string
	DocType           string
	OriginalFilename  string
	S3Key             string
	MimeType          string
	FileSizeBytes     int64
	IngestChannel     string
	WhatsAppMessageID string
	SenderPhone       string
	JobID             string
}

func (r *DocumentsRepo) Create(ctx context.Context, in CreateDocumentInput) (*DocumentItem, error) {
	documentID := uuid.NewString()
	now := nowISO()
	status := "INGESTED"
	item := DocumentItem{
		PK:                db.TenantPK(in.TenantID),
		SK:                db.DocumentSK(documentID),
		GSI1PK:            db.DocumentGSI1PK(in.TenantID, status),
		GSI1SK:            db.DocumentGSI1SK(now, documentID),
		DocumentID:        documentID,
		TenantID:          in.TenantID,
		DocType:           in.DocType,
		OriginalFilename:  in.OriginalFilename,
		S3Key:             in.S3Key,
		MimeType:          in.MimeType,
		FileSizeBytes:     in.FileSizeBytes,
		IngestChannel:     in.IngestChannel,
		WhatsAppMessageID: in.WhatsAppMessageID,
		SenderPhone:       in.SenderPhone,
		ProcessingStatus:  status,
		JobID:             in.JobID,
		Currency:          "INR",
		CreatedAt:         now,
		UpdatedAt:         now,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

// FieldUpdate is one field=value pair for UpdateFields. Using
// interface{} values (kept simple over generics) mirrors the Python
// version's **fields kwargs — a string, float64, or nil (meaning REMOVE
// the attribute) are the only values ever passed in practice.
type FieldUpdate struct {
	Name  string
	Value interface{} // string | float64 | int64 | nil
}

// UpdateFields performs an atomic partial update via UpdateExpression —
// this is the pattern used by the Lambda worker after OCR/reconciliation
// runs (many concurrent documents being updated at once), so
// UpdateExpression (not read-modify-write PutItem) is the correct choice
// here, unlike tenants.go's simpler approach.
func (r *DocumentsRepo) UpdateFields(ctx context.Context, tenantID, documentID string, updates []FieldUpdate) (*DocumentItem, error) {
	setParts := []string{}
	removeParts := []string{}
	names := map[string]string{}
	values := map[string]types.AttributeValue{}

	var newStatus, newGSTStatus string
	var statusChanged, gstStatusChanged bool

	addUpdate := func(name string, value interface{}) error {
		namePh := "#" + name
		names[namePh] = name
		if value == nil {
			removeParts = append(removeParts, namePh)
			return nil
		}
		av, err := attributevalue.Marshal(value)
		if err != nil {
			return err
		}
		valPh := ":" + name
		values[valPh] = av
		setParts = append(setParts, namePh+" = "+valPh)
		return nil
	}

	for _, u := range updates {
		if err := addUpdate(u.Name, u.Value); err != nil {
			return nil, err
		}
		if u.Name == "processing_status" {
			if s, ok := u.Value.(string); ok {
				newStatus = s
				statusChanged = true
			}
		}
		if u.Name == "gst_portal_status" {
			gstStatusChanged = true
			if u.Value != nil {
				if s, ok := u.Value.(string); ok {
					newGSTStatus = s
				}
			}
		}
	}

	// Keep GSI1 (processing status) in sync.
	if statusChanged && newStatus != "" {
		names["#gsi1pk"] = "gsi1pk"
		values[":gsi1pk"] = &types.AttributeValueMemberS{Value: db.DocumentGSI1PK(tenantID, newStatus)}
		setParts = append(setParts, "#gsi1pk = :gsi1pk")
	}

	// Keep GSI2 (GST status, sparse) in sync.
	if gstStatusChanged {
		names["#gsi2pk"] = "gsi2pk"
		if newGSTStatus != "" {
			values[":gsi2pk"] = &types.AttributeValueMemberS{Value: db.DocumentGSI2PK(tenantID, newGSTStatus)}
			setParts = append(setParts, "#gsi2pk = :gsi2pk")
		} else {
			removeParts = append(removeParts, "#gsi2pk")
		}
	}

	names["#updated_at"] = "updated_at"
	values[":updated_at"] = &types.AttributeValueMemberS{Value: nowISO()}
	setParts = append(setParts, "#updated_at = :updated_at")

	expr := ""
	if len(setParts) > 0 {
		expr += "SET " + strings.Join(setParts, ", ")
	}
	if len(removeParts) > 0 {
		if expr != "" {
			expr += " "
		}
		expr += "REMOVE " + strings.Join(removeParts, ", ")
	}

	out, err := r.client.UpdateItem(ctx, &dynamodb.UpdateItemInput{
		TableName: aws.String(db.TableName()),
		Key: map[string]types.AttributeValue{
			"pk": &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			"sk": &types.AttributeValueMemberS{Value: db.DocumentSK(documentID)},
		},
		UpdateExpression:          aws.String(expr),
		ExpressionAttributeNames:  names,
		ExpressionAttributeValues: values,
		ReturnValues:              types.ReturnValueAllNew,
	})
	if err != nil {
		return nil, err
	}
	var item DocumentItem
	if err := attributevalue.UnmarshalMap(out.Attributes, &item); err != nil {
		return nil, err
	}
	return &item, nil
}

func (r *DocumentsRepo) queryAllPages(ctx context.Context, input *dynamodb.QueryInput) ([]map[string]types.AttributeValue, error) {
	var items []map[string]types.AttributeValue
	paginator := dynamodb.NewQueryPaginator(r.client, input)
	for paginator.HasMorePages() {
		page, err := paginator.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		items = append(items, page.Items...)
	}
	return items, nil
}

// ListByTenant backs GET /documents. See documents.py's identical
// skip/limit-in-Python (here, in-Go) tradeoff note — DynamoDB has no
// native offset pagination, so the full matching set is fetched and
// sliced. Bounded by expected per-tenant document volume at this app's
// scale (see DYNAMODB_SCHEMA.md).
func (r *DocumentsRepo) ListByTenant(ctx context.Context, tenantID, status, docType string, skip, limit int) ([]DocumentItem, int, error) {
	var rawItems []map[string]types.AttributeValue
	var err error

	if status != "" {
		rawItems, err = r.queryAllPages(ctx, &dynamodb.QueryInput{
			TableName:              aws.String(db.TableName()),
			IndexName:              aws.String("GSI1"),
			KeyConditionExpression: aws.String("gsi1pk = :pk"),
			ExpressionAttributeValues: map[string]types.AttributeValue{
				":pk": &types.AttributeValueMemberS{Value: db.DocumentGSI1PK(tenantID, strings.ToUpper(status))},
			},
			ScanIndexForward: aws.Bool(false),
		})
	} else {
		rawItems, err = r.queryAllPages(ctx, &dynamodb.QueryInput{
			TableName:              aws.String(db.TableName()),
			KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
			ExpressionAttributeValues: map[string]types.AttributeValue{
				":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
				":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
			},
		})
	}
	if err != nil {
		return nil, 0, err
	}

	var items []DocumentItem
	for _, raw := range rawItems {
		var d DocumentItem
		if err := attributevalue.UnmarshalMap(raw, &d); err != nil {
			return nil, 0, err
		}
		if docType != "" && !strings.EqualFold(d.DocType, docType) {
			continue
		}
		items = append(items, d)
	}

	if status == "" {
		sort.Slice(items, func(i, j int) bool { return items[i].CreatedAt > items[j].CreatedAt })
	}

	total := len(items)
	end := skip + limit
	if skip > total {
		skip = total
	}
	if end > total {
		end = total
	}
	return items[skip:end], total, nil
}

func (r *DocumentsRepo) ListByStatus(ctx context.Context, tenantID, status string) ([]DocumentItem, error) {
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI1"),
		KeyConditionExpression: aws.String("gsi1pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.DocumentGSI1PK(tenantID, strings.ToUpper(status))},
		},
	})
	if err != nil {
		return nil, err
	}
	return unmarshalDocuments(raw)
}

func (r *DocumentsRepo) CountByStatus(ctx context.Context, tenantID, status string) (int, error) {
	count := 0
	paginator := dynamodb.NewQueryPaginator(r.client, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI1"),
		KeyConditionExpression: aws.String("gsi1pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.DocumentGSI1PK(tenantID, strings.ToUpper(status))},
		},
		Select: types.SelectCount,
	})
	for paginator.HasMorePages() {
		page, err := paginator.NextPage(ctx)
		if err != nil {
			return 0, err
		}
		count += int(page.Count)
	}
	return count, nil
}

func (r *DocumentsRepo) CountTotal(ctx context.Context, tenantID string) (int, error) {
	count := 0
	paginator := dynamodb.NewQueryPaginator(r.client, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
		},
		Select: types.SelectCount,
	})
	for paginator.HasMorePages() {
		page, err := paginator.NextPage(ctx)
		if err != nil {
			return 0, err
		}
		count += int(page.Count)
	}
	return count, nil
}

func (r *DocumentsRepo) ListByGSTStatus(ctx context.Context, tenantID, gstStatus string) ([]DocumentItem, error) {
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		IndexName:              aws.String("GSI2"),
		KeyConditionExpression: aws.String("gsi2pk = :pk"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk": &types.AttributeValueMemberS{Value: db.DocumentGSI2PK(tenantID, strings.ToUpper(gstStatus))},
		},
	})
	if err != nil {
		return nil, err
	}
	return unmarshalDocuments(raw)
}

// ListInvoicesWithTaxIdentifier backs GET /gst/vendor-status. See
// documents.py's identical note: reads every DOCUMENT# item for the
// tenant since doc_type+tax_identifier-presence isn't covered by any
// GSI — acceptable at this app's per-tenant document volume.
func (r *DocumentsRepo) ListInvoicesWithTaxIdentifier(ctx context.Context, tenantID string) ([]DocumentItem, error) {
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		FilterExpression:       aws.String("doc_type = :dt AND attribute_exists(tax_identifier)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
			":dt":     &types.AttributeValueMemberS{Value: "INVOICE"},
		},
	})
	if err != nil {
		return nil, err
	}
	return unmarshalDocuments(raw)
}

// GetByS3Key is an ownership check for the local-storage file-serving
// endpoint (dev mode only) — queries this tenant's documents and filters
// by s3_key. Acceptable cost since this path only runs in local
// development (STORAGE_BACKEND=local), never in production.
func (r *DocumentsRepo) GetByS3Key(ctx context.Context, tenantID, s3Key string) (*DocumentItem, error) {
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		FilterExpression:       aws.String("s3_key = :key"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
			":key":    &types.AttributeValueMemberS{Value: s3Key},
		},
	})
	if err != nil {
		return nil, err
	}
	if len(raw) == 0 {
		return nil, ErrNotFound
	}
	items, err := unmarshalDocuments(raw)
	if err != nil {
		return nil, err
	}
	return &items[0], nil
}

// FindDuplicate looks for an existing INVOICE document belonging to this
// tenant that matches the given one on either (a) same vendor name +
// same invoice number, or (b) same vendor name + same amount + same
// document date — the two heuristics production bank-reconciliation
// tools use since invoice numbers aren't always reliably OCR'd. Same
// bounded per-tenant-scan tradeoff as ListInvoicesWithTaxIdentifier
// (no GSI covers this access pattern; fine at this app's document
// volume). excludeDocumentID skips the document being checked itself.
func (r *DocumentsRepo) FindDuplicate(ctx context.Context, tenantID, vendorName, invoiceNumber string, amount float64, documentDate, excludeDocumentID string) (*DocumentItem, error) {
	if vendorName == "" {
		return nil, nil
	}
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		FilterExpression:       aws.String("doc_type = :dt"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
			":dt":     &types.AttributeValueMemberS{Value: "INVOICE"},
		},
	})
	if err != nil {
		return nil, err
	}
	items, err := unmarshalDocuments(raw)
	if err != nil {
		return nil, err
	}
	normVendor := strings.ToLower(strings.TrimSpace(vendorName))
	for _, d := range items {
		if d.DocumentID == excludeDocumentID {
			continue
		}
		if !strings.EqualFold(strings.TrimSpace(d.VendorName), normVendor) {
			continue
		}
		sameInvoiceNumber := invoiceNumber != "" && strings.EqualFold(strings.TrimSpace(d.InvoiceNumber), strings.TrimSpace(invoiceNumber))
		sameAmountAndDate := amount != 0 && d.RawTotalAmount == amount && documentDate != "" && d.DocumentDate == documentDate
		if sameInvoiceNumber || sameAmountAndDate {
			match := d
			return &match, nil
		}
	}
	return nil, nil
}

// ListVendorNames returns the distinct, non-empty vendor names this
// tenant has ever uploaded an invoice for — used by missing-invoice
// detection to fuzzy-match bank narrations against known vendors.
func (r *DocumentsRepo) ListVendorNames(ctx context.Context, tenantID string) ([]string, error) {
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
		},
	})
	if err != nil {
		return nil, err
	}
	items, err := unmarshalDocuments(raw)
	if err != nil {
		return nil, err
	}
	seen := map[string]bool{}
	var names []string
	for _, d := range items {
		v := strings.TrimSpace(d.VendorName)
		if v == "" || seen[strings.ToLower(v)] {
			continue
		}
		seen[strings.ToLower(v)] = true
		names = append(names, v)
	}
	return names, nil
}

// ListAllForExport returns every document for this tenant, newest
// first — backs the CSV export endpoint. Same bounded-scan tradeoff as
// every other whole-tenant read in this file.
func (r *DocumentsRepo) ListAllForExport(ctx context.Context, tenantID string) ([]DocumentItem, error) {
	raw, err := r.queryAllPages(ctx, &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "DOCUMENT#"},
		},
	})
	if err != nil {
		return nil, err
	}
	items, err := unmarshalDocuments(raw)
	if err != nil {
		return nil, err
	}
	sort.Slice(items, func(i, j int) bool { return items[i].CreatedAt > items[j].CreatedAt })
	return items, nil
}

func unmarshalDocuments(raw []map[string]types.AttributeValue) ([]DocumentItem, error) {
	items := make([]DocumentItem, 0, len(raw))
	for _, r := range raw {
		var d DocumentItem
		if err := attributevalue.UnmarshalMap(r, &d); err != nil {
			return nil, err
		}
		items = append(items, d)
	}
	return items, nil
}

// F is a tiny constructor helper so call sites read naturally:
//
//	repo.UpdateFields(ctx, tid, did, []repository.FieldUpdate{
//	    repository.F("processing_status", "PARSED"),
//	    repository.F("vendor_name", "Acme Corp"),
//	})
func F(name string, value interface{}) FieldUpdate { return FieldUpdate{Name: name, Value: value} }
