package repository

import (
	"context"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb/types"
	"github.com/google/uuid"

	"github.com/marginpulse/backend/internal/db"
)

// AuditLogsRepo is intentionally append-only — no Update/Delete method
// exists on this repo, on purpose. An audit trail that can be edited
// after the fact isn't an audit trail.
type AuditLogsRepo struct{ client *dynamodb.Client }

func NewAuditLogsRepo() *AuditLogsRepo { return &AuditLogsRepo{client: db.Client()} }

type CreateAuditLogInput struct {
	TenantID   string
	EntityType string // e.g. "DOCUMENT", "ANOMALY", "BANKTXN"
	EntityID   string
	Action     string // e.g. "MANUAL_CORRECTION", "ANOMALY_RESOLVED", "ANOMALY_CREATED"
	FieldName  string
	OldValue   string
	NewValue   string
	Reason     string
	ActorEmail string
}

func (r *AuditLogsRepo) Create(ctx context.Context, in CreateAuditLogInput) (*AuditLogItem, error) {
	auditLogID := uuid.NewString()
	now := nowISO()
	item := AuditLogItem{
		PK:         db.TenantPK(in.TenantID),
		SK:         db.AuditLogSK(now, auditLogID),
		AuditLogID: auditLogID,
		TenantID:   in.TenantID,
		EntityType: in.EntityType,
		EntityID:   in.EntityID,
		Action:     in.Action,
		FieldName:  in.FieldName,
		OldValue:   in.OldValue,
		NewValue:   in.NewValue,
		Reason:     in.Reason,
		ActorEmail: in.ActorEmail,
		CreatedAt:  now,
	}
	av, err := attributevalue.MarshalMap(item)
	if err != nil {
		return nil, err
	}
	if _, err := r.client.PutItem(ctx, &dynamodb.PutItemInput{
		TableName: aws.String(db.TableName()),
		Item:      av,
	}); err != nil {
		return nil, err
	}
	return &item, nil
}

// ListByTenant returns this tenant's most recent audit entries
// (newest first), optionally filtered to one entity (entityType +
// entityID both non-empty) — e.g. the full history for one document.
// Same bounded-scan-then-filter tradeoff as anomalies.go/documents.go:
// fine at this app's expected per-tenant audit-log volume.
func (r *AuditLogsRepo) ListByTenant(ctx context.Context, tenantID, entityType, entityID string, limit int32) ([]AuditLogItem, error) {
	input := &dynamodb.QueryInput{
		TableName:              aws.String(db.TableName()),
		KeyConditionExpression: aws.String("pk = :pk AND begins_with(sk, :prefix)"),
		ExpressionAttributeValues: map[string]types.AttributeValue{
			":pk":     &types.AttributeValueMemberS{Value: db.TenantPK(tenantID)},
			":prefix": &types.AttributeValueMemberS{Value: "AUDITLOG#"},
		},
		ScanIndexForward: aws.Bool(false),
	}
	if entityType != "" && entityID != "" {
		input.FilterExpression = aws.String("entity_type = :et AND entity_id = :eid")
		input.ExpressionAttributeValues[":et"] = &types.AttributeValueMemberS{Value: entityType}
		input.ExpressionAttributeValues[":eid"] = &types.AttributeValueMemberS{Value: entityID}
	}
	if limit <= 0 {
		limit = 100
	}

	var items []AuditLogItem
	paginator := dynamodb.NewQueryPaginator(r.client, input)
	for paginator.HasMorePages() && int32(len(items)) < limit {
		page, err := paginator.NextPage(ctx)
		if err != nil {
			return nil, err
		}
		for _, raw := range page.Items {
			var a AuditLogItem
			if err := attributevalue.UnmarshalMap(raw, &a); err != nil {
				return nil, err
			}
			items = append(items, a)
			if int32(len(items)) >= limit {
				break
			}
		}
	}
	return items, nil
}
