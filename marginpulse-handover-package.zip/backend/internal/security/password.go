// Package security ports app/core/security.py, app/core/field_encryption.py,
// and app/core/token_blocklist.py.
package security

import (
	"errors"

	"golang.org/x/crypto/bcrypt"
)

// bcrypt has a hard 72-byte input limit; MAX_PASSWORD_LENGTH stays well
// below that (128 chars) so this and the request-validation layer agree
// — same Long-Password-DoS guard as the Python version's docstring
// explains (a huge password would otherwise make bcrypt itself grind).
const (
	MaxPasswordLength = 128
	MinPasswordLength = 8
	bcryptCost        = 12
)

var (
	ErrPasswordTooShort = errors.New("password must be at least 8 characters")
	ErrPasswordTooLong  = errors.New("password must not exceed 128 characters")
)

// HashPassword hashes a plaintext password with bcrypt (salted, cost 12).
func HashPassword(plain string) (string, error) {
	if len(plain) < MinPasswordLength {
		return "", ErrPasswordTooShort
	}
	if len(plain) > MaxPasswordLength {
		return "", ErrPasswordTooLong
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(plain), bcryptCost)
	if err != nil {
		return "", err
	}
	return string(hash), nil
}

// VerifyPassword checks a plaintext password against its bcrypt hash.
// Never returns an error — a malformed hash or oversized input simply
// fails closed (returns false), matching the Python version's behavior
// of catching ValueError/TypeError rather than propagating them.
func VerifyPassword(plain, hashed string) bool {
	if plain == "" || len(plain) > MaxPasswordLength {
		return false
	}
	err := bcrypt.CompareHashAndPassword([]byte(hashed), []byte(plain))
	return err == nil
}

// DummyHash is used to equalize response timing when a user doesn't
// exist, exactly like auth.py's _DUMMY_HASH — VerifyPassword is always
// called (against this if no real user is found) so login's response
// time doesn't leak whether an email is registered.
const DummyHash = "$2a$12$CwTycUXWue0Thq9StjUM0uJ8s37Q6Xkn1.NkA1kS9bZQ4hX5xZ5x2"
