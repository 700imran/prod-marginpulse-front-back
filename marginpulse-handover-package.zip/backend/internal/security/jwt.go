package security

import (
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/marginpulse/backend/internal/config"
)

// Claims mirrors the payload shape create_access_token/create_refresh_token
// produced in Python: sub, tenant_id, type, jti, plus jwt's standard exp.
type Claims struct {
	Subject  string `json:"sub"`
	TenantID string `json:"tenant_id"`
	Type     string `json:"type"` // "access" | "refresh"
	JTI      string `json:"jti"`
	jwt.RegisteredClaims
}

func newJTI() string {
	// 32 hex chars, same shape as Python's uuid.uuid4().hex.
	id, err := randomHex(16)
	if err != nil {
		// crypto/rand failure is exceptionally rare (kernel entropy
		// source failure) — falling back to a timestamp-based value
		// keeps token issuance available rather than hard-failing every
		// login, at the cost of slightly weaker jti uniqueness in that
		// extreme edge case.
		return fmt.Sprintf("fallback%d", time.Now().UnixNano())
	}
	return id
}

func createToken(subject, tenantID, tokenType string, ttl time.Duration) (string, error) {
	cfg := config.Get()
	now := time.Now().UTC()
	claims := Claims{
		Subject:  subject,
		TenantID: tenantID,
		Type:     tokenType,
		JTI:      newJTI(),
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(cfg.JWTSecretKey))
}

// CreateAccessToken mirrors create_access_token().
func CreateAccessToken(subject, tenantID string) (string, error) {
	cfg := config.Get()
	return createToken(subject, tenantID, "access", time.Duration(cfg.JWTAccessTokenExpireMinutes)*time.Minute)
}

// CreateRefreshToken mirrors create_refresh_token().
func CreateRefreshToken(subject, tenantID string) (string, error) {
	cfg := config.Get()
	return createToken(subject, tenantID, "refresh", time.Duration(cfg.JWTRefreshTokenExpireDays)*24*time.Hour)
}

// DecodeToken mirrors decode_token() — returns an error on
// invalid/expired/tampered tokens (jwt/v5 validates exp automatically).
func DecodeToken(tokenString string) (*Claims, error) {
	cfg := config.Get()
	claims := &Claims{}
	token, err := jwt.ParseWithClaims(tokenString, claims, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
		}
		return []byte(cfg.JWTSecretKey), nil
	})
	if err != nil {
		return nil, err
	}
	if !token.Valid {
		return nil, fmt.Errorf("invalid token")
	}
	return claims, nil
}

// SecondsUntilExpiry mirrors auth.py's _ttl_from_exp() — used so a
// blocklist entry expires at the same time the token naturally would.
func SecondsUntilExpiry(claims *Claims) int64 {
	if claims.ExpiresAt == nil {
		return 0
	}
	remaining := int64(time.Until(claims.ExpiresAt.Time).Seconds())
	if remaining < 0 {
		return 0
	}
	return remaining
}
