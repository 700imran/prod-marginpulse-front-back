package security

import (
	"crypto/rand"
	"encoding/hex"
)

// randomHex returns n random bytes hex-encoded (2n hex characters) —
// used for JWT jti generation (mirrors Python's uuid.uuid4().hex, which
// is also just random hex under the hood).
func randomHex(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}
