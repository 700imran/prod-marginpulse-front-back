// Package security's field_encryption.go ports app/core/field_encryption.py.
//
// WHY AES-256-GCM INSTEAD OF FERNET: Fernet (Python's cryptography
// library) is AES-128-CBC + HMAC-SHA256 wrapped in a specific framing.
// Go's standard library doesn't ship Fernet, but crypto/aes +
// crypto/cipher's GCM mode is the direct, stdlib-only equivalent —
// authenticated encryption (confidentiality + tamper detection, same
// guarantee Fernet provides via its HMAC), using AES-256 instead of
// Fernet's AES-128 (strictly stronger), with zero third-party
// dependencies. This does mean ciphertext encrypted by the Python
// version is NOT decryptable by this Go version and vice versa — bank
// account numbers encrypted under the old Python deployment must be
// decrypted with the OLD code and re-encrypted under this one during
// cutover (see MIGRATION_NOTES in the top-level docs), a one-time
// migration script, not an ongoing compatibility requirement.
package security

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"io"
	"strings"

	"github.com/marginpulse/backend/internal/config"
)

var ErrInvalidCiphertext = errors.New("field data is invalid or has been tampered with")

// deriveKey turns FIELD_ENCRYPTION_KEY (any string) into a valid 32-byte
// AES-256 key via SHA-256 — same "any sufficiently random string works,
// no manual key-formatting needed" ergonomics as the Python version's
// _derive_fernet_key().
func deriveKey(secret string) []byte {
	sum := sha256.Sum256([]byte(secret))
	return sum[:]
}

func gcmCipher() (cipher.AEAD, error) {
	key := deriveKey(config.Get().FieldEncryptionKey)
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

// EncryptField encrypts a string for storage, returning a base64
// ciphertext string (nonce prepended, standard GCM usage pattern).
func EncryptField(plaintext string) (string, error) {
	if plaintext == "" {
		return "", errors.New("cannot encrypt an empty value")
	}
	gcm, err := gcmCipher()
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := gcm.Seal(nonce, nonce, []byte(plaintext), nil)
	return base64.URLEncoding.EncodeToString(ciphertext), nil
}

// DecryptField decrypts a previously-encrypted field. Returns
// ErrInvalidCiphertext on tampered/invalid input rather than a raw
// crypto error, matching the Python version's error-wrapping behavior.
func DecryptField(ciphertextB64 string) (string, error) {
	gcm, err := gcmCipher()
	if err != nil {
		return "", err
	}
	data, err := base64.URLEncoding.DecodeString(ciphertextB64)
	if err != nil {
		return "", ErrInvalidCiphertext
	}
	nonceSize := gcm.NonceSize()
	if len(data) < nonceSize {
		return "", ErrInvalidCiphertext
	}
	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", ErrInvalidCiphertext
	}
	return string(plaintext), nil
}

// MaskAccountNumber returns only the last 4 digits — safe for display.
func MaskAccountNumber(accountNumber string) string {
	var digits strings.Builder
	for _, c := range accountNumber {
		if c >= '0' && c <= '9' {
			digits.WriteRune(c)
		}
	}
	d := digits.String()
	if len(d) < 4 {
		return "****"
	}
	return d[len(d)-4:]
}
