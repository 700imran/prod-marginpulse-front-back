package security

import (
	"context"
	"fmt"
	"log/slog"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"

	"github.com/marginpulse/backend/internal/config"
)

const blocklistPrefix = "mp:revoked_token:"

var blocklistClient *redis.Client

// redisDBSuffix swaps the trailing /N database-index segment of a Redis
// URL — mirrors the Python version's `_redis_url.rsplit("/", 1)[0] + "/4"`
// so token revocation uses its own logical namespace (db 4) on the same
// physical Redis instance already used for rate limiting (db 0) and the
// AI budget guard (db 5), with zero collision risk.
func redisDBSuffix(url string, db int) string {
	idx := strings.LastIndex(url, "/")
	if idx == -1 {
		return url
	}
	return fmt.Sprintf("%s/%d", url[:idx], db)
}

func getBlocklistClient() *redis.Client {
	if blocklistClient == nil {
		opts, err := redis.ParseURL(redisDBSuffix(config.Get().RedisURL, 4))
		if err != nil {
			slog.Error("invalid REDIS_URL for token blocklist", "error", err)
			opts = &redis.Options{Addr: "localhost:6379"}
		}
		opts.DialTimeout = 5 * time.Second
		opts.ReadTimeout = 5 * time.Second
		blocklistClient = redis.NewClient(opts)
	}
	return blocklistClient
}

// RevokeToken marks a token's jti as revoked, with a TTL matching its
// remaining lifetime. Fails silently (logs only) on Redis errors — same
// "best-effort security measure on top of normal expiry, not the only
// thing standing between a token and being unusable" tradeoff as the
// Python version.
func RevokeToken(ctx context.Context, jti string, ttlSeconds int64) {
	if ttlSeconds <= 0 || jti == "" {
		return
	}
	client := getBlocklistClient()
	if err := client.Set(ctx, blocklistPrefix+jti, "1", time.Duration(ttlSeconds)*time.Second).Err(); err != nil {
		slog.Error("could not write token revocation to redis", "jti", jti, "error", err)
	}
}

// IsRevoked checks whether a token's jti has been revoked. Fails CLOSED
// in the sense of "treat as not revoked" on a Redis error — same
// rationale as the Python version: rate limiting is the secondary
// backstop, and a Redis blip shouldn't lock every user out.
func IsRevoked(ctx context.Context, jti string) bool {
	if jti == "" {
		return false
	}
	client := getBlocklistClient()
	n, err := client.Exists(ctx, blocklistPrefix+jti).Result()
	if err != nil {
		return false
	}
	return n == 1
}
