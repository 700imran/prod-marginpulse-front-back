// Package logging configures log/slog (Go's standard-library structured
// logger, added in Go 1.21) as a JSON logger — the direct stdlib
// equivalent of structlog's JSONRenderer in app/core/logging.py. No
// external dependency needed for this, unlike the Python version which
// required the separate structlog package.
package logging

import (
	"context"
	"log/slog"
	"os"

	"github.com/marginpulse/backend/internal/config"
)

type ctxKey string

const requestIDKey ctxKey = "request_id"

// Configure sets the global slog default logger. In debug mode, uses a
// human-readable text handler (mirrors structlog.dev.ConsoleRenderer);
// otherwise JSON (mirrors structlog.processors.JSONRenderer) — this is
// what CloudWatch Logs Insights queries against in production.
func Configure() {
	cfg := config.Get()
	level := parseLevel(cfg.LogLevel)

	var handler slog.Handler
	opts := &slog.HandlerOptions{Level: level}
	if cfg.AppDebug {
		handler = slog.NewTextHandler(os.Stdout, opts)
	} else {
		handler = slog.NewJSONHandler(os.Stdout, opts)
	}
	slog.SetDefault(slog.New(handler))
}

func parseLevel(level string) slog.Level {
	switch level {
	case "DEBUG":
		return slog.LevelDebug
	case "WARNING", "WARN":
		return slog.LevelWarn
	case "ERROR":
		return slog.LevelError
	default:
		return slog.LevelInfo
	}
}

// WithRequestID returns a context carrying the request ID, and a logger
// with that ID bound as a field on every subsequent log call — the Go
// equivalent of structlog.contextvars.bind_contextvars(request_id=...)
// used in main.py's middleware. Since Go has no implicit thread-local
// context the way Python's contextvars do, the pattern here is explicit:
// pass the returned context (and logger, when convenient) down the call
// chain rather than relying on ambient state.
func WithRequestID(ctx context.Context, requestID string) (context.Context, *slog.Logger) {
	ctx = context.WithValue(ctx, requestIDKey, requestID)
	logger := slog.Default().With("request_id", requestID)
	return ctx, logger
}

// RequestIDFromContext retrieves the request ID bound by WithRequestID,
// or "" if none was ever bound (e.g. a background goroutine started
// without it).
func RequestIDFromContext(ctx context.Context) string {
	if v, ok := ctx.Value(requestIDKey).(string); ok {
		return v
	}
	return ""
}
